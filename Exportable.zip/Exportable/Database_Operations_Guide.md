# Database Operations - Exportable Documentation

This document provides comprehensive guidance for implementing database operations following MTM standards in any .NET application. All patterns enforce the critical "stored procedures only" security rule.

## ?? CRITICAL DATABASE SECURITY RULES ??

### **STORED PROCEDURES ONLY**
- **ALL** database operations must use stored procedures
- **ZERO** hard-coded SQL commands in application code
- Direct SQL execution will result in security violations
- This rule applies to ALL database interactions without exception

### **FILE ORGANIZATION PRINCIPLE**
- **Production Files** - **READ-ONLY** - Current production state
- **Development Files** - **EDITABLE** - All development work
- **NEVER** edit production files directly during development
- **ALWAYS** work in development files and deploy through proper change management

---

## ?? Database Operation Patterns

### 1. Basic Stored Procedure Call Pattern
```csharp
public async Task<Result<List<InventoryItem>>> GetInventoryByLocationAsync(string location)
{
    try
    {
        var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
            "inv_inventory_Get_ByLocation",
            new Dictionary<string, object> 
            { 
                ["p_Location"] = location 
            }
        );

        return result.IsSuccess 
            ? Result<List<InventoryItem>>.Success(result.Value)
            : Result<List<InventoryItem>>.Failure(result.Error);
    }
    catch (Exception ex)
    {
        return Result<List<InventoryItem>>.Failure($"Database error: {ex.Message}");
    }
}
```

### 2. Stored Procedure with Status Pattern
```csharp
public async Task<Result<bool>> AddInventoryItemAsync(InventoryItem item)
{
    try
    {
        var result = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
            "inv_inventory_Add_Item",
            new Dictionary<string, object>
            {
                ["p_PartID"] = item.PartID,
                ["p_Location"] = item.Location,
                ["p_Operation"] = item.Operation,
                ["p_Quantity"] = item.Quantity,
                ["p_ItemType"] = item.ItemType,
                ["p_User"] = item.User,
                ["p_Notes"] = item.Notes
            }
        );

        if (!result.IsSuccess)
            return Result<bool>.Failure(result.Error);

        var procedureResult = result.Value;
        return procedureResult.IsSuccess
            ? Result<bool>.Success(true)
            : Result<bool>.Failure(procedureResult.ErrorMessage ?? "Operation failed");
    }
    catch (Exception ex)
    {
        return Result<bool>.Failure($"Database error: {ex.Message}");
    }
}
```

### 3. Transaction Pattern
```csharp
public async Task<Result<bool>> TransferInventoryAsync(string partId, string fromLocation, string toLocation, int quantity, string user)
{
    try
    {
        return await _databaseService.ExecuteTransactionAsync(async (connection, transaction) =>
        {
            // Step 1: Remove from source location
            var removeResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
                "inv_inventory_Remove_Item",
                new Dictionary<string, object>
                {
                    ["p_PartID"] = partId,
                    ["p_Location"] = fromLocation,
                    ["p_Quantity"] = quantity,
                    ["p_User"] = user,
                    ["p_TransactionType"] = "TRANSFER"
                }
            );

            if (!removeResult.IsSuccess || !removeResult.Value.IsSuccess)
                throw new InvalidOperationException($"Failed to remove inventory: {removeResult.Value.ErrorMessage}");

            // Step 2: Add to destination location
            var addResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
                "inv_inventory_Add_Item",
                new Dictionary<string, object>
                {
                    ["p_PartID"] = partId,
                    ["p_Location"] = toLocation,
                    ["p_Quantity"] = quantity,
                    ["p_User"] = user,
                    ["p_TransactionType"] = "TRANSFER"
                }
            );

            if (!addResult.IsSuccess || !addResult.Value.IsSuccess)
                throw new InvalidOperationException($"Failed to add inventory: {addResult.Value.ErrorMessage}");

            return true;
        });
    }
    catch (Exception ex)
    {
        return Result<bool>.Failure($"Transfer failed: {ex.Message}");
    }
}
```

## ??? MTM Business Logic Patterns

### Critical Transaction Type Logic
```csharp
/// <summary>
/// CRITICAL: TransactionType is determined by USER INTENT, NOT operation numbers.
/// Operations (90, 100, 110) are workflow step identifiers only.
/// </summary>
public async Task<Result<bool>> ProcessInventoryOperationAsync(InventoryOperationRequest request)
{
    try 
    {
        // Determine TransactionType based on USER ACTION, not Operation number
        string transactionType = request.UserAction switch
        {
            "ADD_STOCK" => "IN",      // User is adding stock to inventory
            "REMOVE_STOCK" => "OUT",  // User is removing stock from inventory
            "TRANSFER_STOCK" => "TRANSFER", // User is moving stock between locations
            _ => throw new ArgumentException($"Unknown user action: {request.UserAction}")
        };

        var result = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
            "inv_inventory_Process_Operation",
            new Dictionary<string, object>
            {
                ["p_PartID"] = request.PartID,
                ["p_Location"] = request.Location,
                ["p_Operation"] = request.Operation, // Just a workflow step number
                ["p_Quantity"] = request.Quantity,
                ["p_ItemType"] = request.ItemType,
                ["p_User"] = request.User,
                ["p_Notes"] = request.Notes,
                ["p_TransactionType"] = transactionType // Based on user intent, NOT operation
            }
        );
        
        return result.IsSuccess 
            ? Result<bool>.Success(result.Value.IsSuccess)
            : Result<bool>.Failure(result.Error);
    }
    catch (Exception ex)
    {
        return Result<bool>.Failure($"Failed to process inventory operation: {ex.Message}");
    }
}
```

## ?? Stored Procedure Standards

### Naming Conventions
| Pattern | Example | Purpose |
|---------|---------|---------|
| `{table}_{action}_{details}` | `inv_inventory_Get_ByPartID` | Get inventory by part ID |
| `{table}_{action}_{entity}` | `inv_inventory_Add_Item` | Add new inventory item |
| `{table}_{action}_{entity}` | `inv_inventory_Update_Quantity` | Update inventory quantity |
| `{module}_{entity}_{action}` | `sys_last_10_transactions_Get_ByUser` | System module operations |

### Standard Stored Procedure Template
```sql
DELIMITER $$
CREATE PROCEDURE procedure_name(
    IN p_Parameter1 VARCHAR(50),
    IN p_Parameter2 INT,
    OUT p_Status INT,
    OUT p_ErrorMsg VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1
            @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
        SET p_Status = -1;
        SET p_ErrorMsg = CONCAT('Database error: ', @p2);
        ROLLBACK;
    END;

    -- Initialize output parameters
    SET p_Status = 0;
    SET p_ErrorMsg = '';

    -- Input validation
    IF p_Parameter1 IS NULL OR p_Parameter1 = '' THEN
        SET p_Status = 1;
        SET p_ErrorMsg = 'Parameter1 cannot be empty';
        LEAVE procedure_name;
    END IF;

    IF p_Parameter2 <= 0 THEN
        SET p_Status = 2;
        SET p_ErrorMsg = 'Parameter2 must be positive';
        LEAVE procedure_name;
    END IF;

    -- Start transaction
    START TRANSACTION;
    
    -- Business logic here
    -- INSERT, UPDATE, DELETE operations
    
    -- Success
    COMMIT;
    SET p_Status = 0;
    SET p_ErrorMsg = 'Operation completed successfully';
    
END$$
DELIMITER ;
```

### Error Handling Standards
```sql
-- Standard error handling pattern
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
    GET DIAGNOSTICS CONDITION 1
        @errno = MYSQL_ERRNO, @sqlstate = RETURNED_SQLSTATE, @text = MESSAGE_TEXT;
    SET p_Status = -1;
    SET p_ErrorMsg = CONCAT('Error ', @errno, ' (', @sqlstate, '): ', @text);
    ROLLBACK;
END;

-- Specific error handling
DECLARE CONTINUE HANDLER FOR SQLSTATE '23000'  -- Integrity constraint violation
BEGIN
    SET p_Status = 10;
    SET p_ErrorMsg = 'Duplicate entry or constraint violation';
END;

DECLARE CONTINUE HANDLER FOR SQLSTATE '42S02'  -- Table doesn't exist
BEGIN
    SET p_Status = 11;
    SET p_ErrorMsg = 'Required table not found';
END;
```

## ?? Security Validation Patterns

### Input Validation in Stored Procedures
```sql
-- String parameter validation
IF p_PartID IS NULL OR p_PartID = '' OR LENGTH(p_PartID) > 50 THEN
    SET p_Status = 1;
    SET p_ErrorMsg = 'PartID must be between 1 and 50 characters';
    LEAVE procedure_name;
END IF;

-- Numeric parameter validation
IF p_Quantity IS NULL OR p_Quantity <= 0 OR p_Quantity > 999999 THEN
    SET p_Status = 2;
    SET p_ErrorMsg = 'Quantity must be between 1 and 999999';
    LEAVE procedure_name;
END IF;

-- User validation (check if user exists)
IF NOT EXISTS (SELECT 1 FROM usr_users WHERE User_Name = p_User) THEN
    SET p_Status = 3;
    SET p_ErrorMsg = 'Invalid user specified';
    LEAVE procedure_name;
END IF;

-- Location validation
IF NOT EXISTS (SELECT 1 FROM md_locations WHERE Location = p_Location) THEN
    SET p_Status = 4;
    SET p_ErrorMsg = 'Invalid location specified';
    LEAVE procedure_name;
END IF;
```

### Application-Level Security Validation
```csharp
/// <summary>
/// Validates that the input is a procedure name and not SQL code.
/// Prevents SQL injection and enforces stored procedure usage.
/// </summary>
private static bool IsSqlQuery(string input)
{
    if (string.IsNullOrWhiteSpace(input))
        return false;

    var lowerInput = input.Trim().ToLowerInvariant();
    
    // Check for SQL keywords that indicate direct SQL rather than procedure names
    var sqlKeywords = new[]
    {
        "select", "insert", "update", "delete", "drop", "create", "alter", 
        "truncate", "grant", "revoke", "union", "join", "where", "from", 
        "into", "values", "set", "exec", "execute", "sp_executesql"
    };

    return sqlKeywords.Any(keyword => lowerInput.Contains(keyword + " ") || 
                                    lowerInput.StartsWith(keyword + " ") ||
                                    lowerInput.Equals(keyword));
}
```

## ?? Common Database Operations

### Inventory Management Operations
```csharp
// Get inventory by Part ID
var inventory = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
    "inv_inventory_Get_ByPartID",
    new Dictionary<string, object> { ["p_PartID"] = partId }
);

// Add inventory item (IN transaction)
var addResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
    "inv_inventory_Add_Item",
    new Dictionary<string, object>
    {
        ["p_PartID"] = item.PartID,
        ["p_Location"] = item.Location,
        ["p_Operation"] = item.Operation,
        ["p_Quantity"] = item.Quantity,
        ["p_TransactionType"] = "IN" // User is adding stock
    }
);

// Remove inventory item (OUT transaction)
var removeResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
    "inv_inventory_Remove_Item",
    new Dictionary<string, object>
    {
        ["p_PartID"] = partId,
        ["p_Quantity"] = quantity,
        ["p_TransactionType"] = "OUT" // User is removing stock
    }
);
```

### User Management Operations
```csharp
// Get user by username
var user = await _databaseService.ExecuteStoredProcedureAsync<User>(
    "usr_users_Get_ByUsername",
    new Dictionary<string, object> { ["p_Username"] = username }
);

// Create new user
var createResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<int>(
    "usr_users_Create_User",
    new Dictionary<string, object>
    {
        ["p_Username"] = request.UserName,
        ["p_FullName"] = request.FullName,
        ["p_Shift"] = request.Shift,
        ["p_VitsUser"] = request.VitsUser,
        ["p_CreatedBy"] = currentUser
    }
);
```

### Error Logging Operations
```csharp
// Log error to database
var logResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
    "log_error_Add_Error",
    new Dictionary<string, object>
    {
        ["p_User"] = userId,
        ["p_Severity"] = severity.ToString(),
        ["p_ErrorType"] = exception.GetType().Name,
        ["p_ErrorMessage"] = exception.Message,
        ["p_StackTrace"] = exception.StackTrace,
        ["p_ModuleName"] = moduleName,
        ["p_MethodName"] = methodName,
        ["p_AdditionalInfo"] = additionalInfo,
        ["p_MachineName"] = Environment.MachineName,
        ["p_OSVersion"] = Environment.OSVersion.ToString(),
        ["p_AppVersion"] = appVersion
    }
);
```

## ?? Performance Optimization Patterns

### Batch Processing Pattern
```csharp
public async Task<Result<int>> ProcessBatchOperationAsync<T>(
    string procedureName, 
    IEnumerable<T> items, 
    Func<T, Dictionary<string, object>> parameterMapper,
    int batchSize = 1000)
{
    var totalProcessed = 0;
    var batches = items.Chunk(batchSize);

    foreach (var batch in batches)
    {
        var result = await _databaseService.ExecuteTransactionAsync(async (connection, transaction) =>
        {
            var batchProcessed = 0;

            foreach (var item in batch)
            {
                var parameters = parameterMapper(item);
                var itemResult = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
                    procedureName,
                    parameters
                );

                if (!itemResult.IsSuccess || !itemResult.Value.IsSuccess)
                    throw new InvalidOperationException($"Batch processing failed: {itemResult.Value.ErrorMessage}");

                batchProcessed++;
            }

            return batchProcessed;
        });

        if (!result.IsSuccess)
            return Result<int>.Failure($"Batch processing failed after {totalProcessed} items: {result.Error}");

        totalProcessed += result.Value;
    }

    return Result<int>.Success(totalProcessed);
}
```

### Caching Pattern for Reference Data
```csharp
public class ReferenceDataService
{
    private readonly IDatabaseService _databaseService;
    private readonly ICacheService _cacheService;
    private readonly TimeSpan _cacheExpiration = TimeSpan.FromHours(1);

    public async Task<Result<List<Location>>> GetLocationsAsync()
    {
        const string cacheKey = "reference_data_locations";
        
        // Try cache first
        var cached = await _cacheService.GetAsync<List<Location>>(cacheKey);
        if (cached != null)
            return Result<List<Location>>.Success(cached);

        // Load from database
        var result = await _databaseService.ExecuteStoredProcedureAsync<Location>(
            "md_locations_Get_All",
            null
        );

        if (!result.IsSuccess)
            return Result<List<Location>>.Failure(result.Error);

        // Cache the result
        await _cacheService.SetAsync(cacheKey, result.Value, _cacheExpiration);

        return Result<List<Location>>.Success(result.Value);
    }
}
```

## ?? Security Considerations

### Connection String Security
```csharp
// ? CORRECT - Use configuration service
public class DatabaseService
{
    private readonly string _connectionString;

    public DatabaseService(IConfigurationService configService)
    {
        _connectionString = configService.GetConnectionString("DefaultConnection") 
            ?? throw new InvalidOperationException("Connection string not found");
    }
}

// ? WRONG - Hard-coded connection strings
// private const string CONNECTION_STRING = "Server=...;Database=...;Uid=...;Pwd=...;";
```

### Parameter Sanitization
```csharp
// ? CORRECT - Validate parameters before database calls
private static Dictionary<string, object> ValidateAndCreateParameters(InventoryItem item)
{
    if (string.IsNullOrWhiteSpace(item.PartID))
        throw new ArgumentException("PartID cannot be empty", nameof(item));
    
    if (item.PartID.Length > 50)
        throw new ArgumentException("PartID cannot exceed 50 characters", nameof(item));
    
    if (item.Quantity < 0)
        throw new ArgumentException("Quantity cannot be negative", nameof(item));

    return new Dictionary<string, object>
    {
        ["p_PartID"] = item.PartID.Trim(),
        ["p_Location"] = item.Location?.Trim() ?? string.Empty,
        ["p_Quantity"] = item.Quantity
    };
}
```

### Audit Logging Pattern
```csharp
public async Task<Result<bool>> AuditedOperationAsync(string operation, string userId, Func<Task<Result<bool>>> databaseOperation)
{
    var startTime = DateTime.UtcNow;
    
    try
    {
        // Log operation start
        await _databaseService.ExecuteStoredProcedureNonQueryAsync(
            "audit_log_Operation_Start",
            new Dictionary<string, object>
            {
                ["p_Operation"] = operation,
                ["p_User"] = userId,
                ["p_StartTime"] = startTime
            }
        );

        // Execute the operation
        var result = await databaseOperation();

        // Log operation completion
        await _databaseService.ExecuteStoredProcedureNonQueryAsync(
            "audit_log_Operation_Complete",
            new Dictionary<string, object>
            {
                ["p_Operation"] = operation,
                ["p_User"] = userId,
                ["p_StartTime"] = startTime,
                ["p_EndTime"] = DateTime.UtcNow,
                ["p_Success"] = result.IsSuccess,
                ["p_ErrorMessage"] = result.IsSuccess ? null : result.Error
            }
        );

        return result;
    }
    catch (Exception ex)
    {
        // Log operation failure
        await _databaseService.ExecuteStoredProcedureNonQueryAsync(
            "audit_log_Operation_Failed",
            new Dictionary<string, object>
            {
                ["p_Operation"] = operation,
                ["p_User"] = userId,
                ["p_StartTime"] = startTime,
                ["p_EndTime"] = DateTime.UtcNow,
                ["p_ErrorMessage"] = ex.Message
            }
        );

        throw;
    }
}
```

---

## ?? Implementation Checklist

### Before Implementing Database Operations
- [ ] Verify connection string is properly configured
- [ ] Ensure database provider NuGet packages are installed
- [ ] Confirm stored procedures exist in database
- [ ] Validate all required parameters are documented
- [ ] Check that error handling patterns are understood

### During Implementation
- [ ] Use only stored procedure calls - NO direct SQL
- [ ] Validate all input parameters before database calls
- [ ] Implement proper error handling with Result<T> patterns
- [ ] Add comprehensive logging for all database operations
- [ ] Use transactions for multi-step operations
- [ ] Include audit logging for sensitive operations

### After Implementation
- [ ] Test all success and failure scenarios
- [ ] Verify error messages are user-friendly and don't expose sensitive data
- [ ] Confirm performance is acceptable under expected load
- [ ] Validate security measures are in place
- [ ] Document all custom stored procedures and their usage
- [ ] Review code for compliance with MTM database standards

---

**Remember**: The goal is to create secure, maintainable, and performant database access layers that enforce business rules at the database level while providing clean, testable interfaces for application code.