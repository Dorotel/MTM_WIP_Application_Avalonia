# MTM Core Systems - Exportable Package

This folder contains exportable versions of all core systems from the MTM WIP Application that can be integrated into any C# application. These systems are framework-agnostic and follow clean architecture principles.

## ?? Table of Contents

- [Installation Guide](#installation-guide)
- [Available Systems](#available-systems)
- [System Dependencies](#system-dependencies)
- [Implementation Examples](#implementation-examples)
- [Custom Prompts](#custom-prompts)
- [MTM Business Patterns](#mtm-business-patterns)
- [Database Security Requirements](#database-security-requirements)
- [Maintenance Instructions](#maintenance-instructions)

---

## ?? Installation Guide

### Prerequisites
- .NET 8.0 or higher
- C# project (Console, Web API, WPF, Avalonia, etc.)

### Step 1: Copy Core Systems
Copy the required system folders from this `Exportable/` directory to your target project:

```
Your_Project/
??? Models/           # Data models and entities (MTM-specific patterns)
??? Services/         # Service interfaces and implementations
??? Configuration/    # Configuration management and validation
??? Extensions/       # Dependency injection setup and extensions
??? Infrastructure/   # Cross-cutting concerns (coming in future updates)
```

### Step 2: Install NuGet Dependencies
Install the required NuGet packages based on which systems you're using:

```powershell
# Core Dependencies (Required for all systems)
dotnet add package Microsoft.Extensions.DependencyInjection
dotnet add package Microsoft.Extensions.Configuration
dotnet add package Microsoft.Extensions.Configuration.Json
dotnet add package Microsoft.Extensions.Logging

# Error Handling and Logging (Service_ErrorHandler, LoggingUtility)
dotnet add package Microsoft.Extensions.Logging.Console
dotnet add package MySql.Data

# Database Service (DatabaseService, stored procedure patterns)
dotnet add package Dapper
dotnet add package MySql.Data

# Validation (Optional - for IValidationService implementations)
dotnet add package FluentValidation

# Caching (Optional - for ICacheService implementations)
dotnet add package Microsoft.Extensions.Caching.Memory

# Testing (Optional - for unit testing infrastructure)
dotnet add package xUnit
dotnet add package Moq
dotnet add package FluentAssertions
```

### Step 3: Configure Dependency Injection
In your application startup (Program.cs or equivalent):

```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using MTM.Core.Extensions;

// Add this line in your service configuration
services.AddMTMCoreServices(configuration);
```

### Step 4: Initialize Configuration
Create `appsettings.json` in your project root:

```json
{
  "Application": {
    "Name": "Your Application Name",
    "Environment": "Development",
    "Theme": "Default",
    "Language": "en-US"
  },
  "ErrorHandling": {
    "EnableFileServerLogging": true,
    "EnableMySqlLogging": false,
    "EnableConsoleLogging": true,
    "FileServerBasePath": "C:\\Logs",
    "MySqlConnectionString": ""
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft": "Warning",
      "Microsoft.Hosting.Lifetime": "Information"
    },
    "File": {
      "Enable": true,
      "Path": "Logs/application.log"
    }
  },
  "Database": {
    "Provider": "MySql",
    "ConnectionString": "Server=localhost;Database=your_db;Uid=user;Pwd=password;",
    "CommandTimeout": 30,
    "MaxRetryAttempts": 3
  }
}
```

### Step 5: Initialize Error Handling
In your application startup:

```csharp
using MTM.Core.Services;

// Initialize error handling system
ErrorHandlingInitializer.Initialize();

// Or for development
ErrorHandlingInitializer.InitializeForDevelopment();
```

---

## ?? Available Systems

### ? Implemented Systems

| System | Files | Description | Dependencies | Status |
|--------|-------|-------------|--------------|--------|
| **Error Handling** | `Services/ErrorHandler/` | Comprehensive error logging and management | MySql.Data | ? Complete |
| **Logging Utility** | `Services/Logging/` | File and database logging utilities | Microsoft.Extensions.Logging | ? Complete |
| **Configuration** | `Configuration/` | Settings management and validation | Microsoft.Extensions.Configuration | ? Complete |
| **Result Pattern** | `Models/Result.cs` | Modern error handling with Result<T> | None | ? Complete |
| **Core Models** | `Models/CoreModels.cs` | MTM-specific data entities and patterns | None | ? Complete |
| **Database Service** | `Services/DatabaseService.cs` | Stored procedure only database access | Dapper, MySql.Data | ? Complete |
| **Service Interfaces** | `Services/Interfaces/` | Framework-agnostic service contracts | None | ? Complete |
| **DI Extensions** | `Extensions/ServiceCollectionExtensions.cs` | Dependency injection setup | Microsoft.Extensions.DI | ? Complete |

### ?? Missing Core Systems (Prompts Available)

| Priority | System | Status | Custom Prompt | Estimated Implementation |
|----------|--------|--------|---------------|-------------------------|
| **CRITICAL** | Application State Service | ?? Missing | [Prompt 27](#27-setup-application-state-management) | 2-4 hours |
| **CRITICAL** | Configuration Service Implementation | ?? Missing | [Prompt 28](#28-implement-configuration-service) | 2-3 hours |
| **HIGH** | Navigation Service | ?? Missing | [Prompt 29](#29-create-navigation-service) | 3-5 hours |
| **HIGH** | Repository Pattern | ?? Missing | [Prompt 31](#31-setup-repository-pattern) | 4-6 hours |
| **HIGH** | Validation System | ?? Missing | [Prompt 32](#32-create-validation-system) | 3-4 hours |
| **MEDIUM** | Theme System | ?? Missing | [Prompt 30](#30-implement-theme-system) | 2-3 hours |
| **MEDIUM** | Caching Layer | ?? Missing | [Prompt 35](#35-create-caching-layer) | 2-3 hours |
| **MEDIUM** | Security Infrastructure | ?? Missing | [Prompt 36](#36-setup-security-infrastructure) | 6-8 hours |
| **LOW** | Unit Testing Infrastructure | ?? Missing | [Prompt 33](#33-create-unit-testing-infrastructure) | 4-6 hours |
| **LOW** | Structured Logging | ?? Missing | [Prompt 34](#34-implement-structured-logging) | 2-3 hours |

---

## ??? System Dependencies

### Core Systems Dependency Graph
```
Configuration Service ? Error Handling System ? Logging Utility
                     ?
                     Result Pattern ? Service Layer ? Repository Pattern
                                   ?
                                   Database Service ? Core Models

Dependency Injection ? All Service Systems

Application State ? Configuration Service
Navigation Service ? Application State (optional)

Validation System ? Core Models
Caching Layer ? Service Layer
Security Infrastructure ? All Services
```

### Recommended Implementation Order
1. **Configuration Service** - Foundation for all other systems
2. **Result Pattern** - Error handling pattern for services (already complete)
3. **Core Models** - Entity foundation (already complete)  
4. **Database Service** - Data access foundation (already complete)
5. **Service Layer** - Business logic implementations
6. **Repository Pattern** - Data access abstraction
7. **Application State** - Global state management
8. **Validation System** - Business rule enforcement
9. **Remaining Systems** - Based on application needs

---

## ?? Implementation Examples

### Basic Error Handling
```csharp
try
{
    // Your business logic
    var result = await inventoryService.ProcessOperationAsync(partId, operation);
    if (!result.IsSuccess)
    {
        // Handle business logic failure
        Console.WriteLine($"Operation failed: {result.Error}");
    }
}
catch (Exception ex)
{
    // Log unexpected errors
    Service_ErrorHandler.HandleException(ex, ErrorSeverity.High, 
        source: "MainProcessor",
        additionalData: new Dictionary<string, object>
        {
            ["PartId"] = partId,
            ["Operation"] = operation
        });
}
```

### Database Operations (Stored Procedures Only)
```csharp
public class InventoryService : IInventoryService
{
    private readonly IDatabaseService _databaseService;
    private readonly ILogger<InventoryService> _logger;

    public InventoryService(IDatabaseService databaseService, ILogger<InventoryService> logger)
    {
        _databaseService = databaseService;
        _logger = logger;
    }

    public async Task<Result<InventoryItem>> GetInventoryItemAsync(string partId)
    {
        try
        {
            _logger.LogInformation("Retrieving inventory item {PartId}", partId);
            
            // CRITICAL: Only stored procedures allowed - NO direct SQL
            var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
                "inv_inventory_Get_ByPartID",
                new Dictionary<string, object> { ["p_PartID"] = partId });

            if (!result.IsSuccess)
                return Result<InventoryItem>.Failure($"Database error: {result.Error}");

            var item = result.Value.FirstOrDefault();
            return item != null 
                ? Result<InventoryItem>.Success(item)
                : Result<InventoryItem>.Failure($"Inventory item {partId} not found");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve inventory item {PartId}", partId);
            return Result<InventoryItem>.Failure($"Database error: {ex.Message}");
        }
    }
}
```

### Configuration Usage
```csharp
// Access configuration values
var connectionString = configService.GetConnectionString("DefaultConnection");
var logLevel = configService.GetValue<string>("Logging:LogLevel:Default");
var databaseTimeout = configService.GetValue<int>("Database:CommandTimeout");

// Validate configuration
var validationResult = configService.ValidateConfiguration();
if (!validationResult.IsSuccess)
{
    throw new InvalidOperationException($"Configuration validation failed: {validationResult.Error}");
}
```

### MTM Business Logic Patterns
```csharp
public async Task<Result<bool>> ProcessInventoryOperationAsync(InventoryOperationRequest request)
{
    try 
    {
        // CRITICAL: TransactionType determined by USER INTENT, not Operation number
        string transactionType = request.UserAction switch
        {
            "ADD_STOCK" => "IN",      // User is adding stock to inventory
            "REMOVE_STOCK" => "OUT",  // User is removing stock from inventory
            "TRANSFER_STOCK" => "TRANSFER", // User is moving stock between locations
            _ => throw new ArgumentException($"Unknown user action: {request.UserAction}")
        };

        var result = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
            "inv_inventory_Process_Operation",
            new Dictionary<string, object>
            {
                ["p_PartID"] = request.PartID,
                ["p_Location"] = request.Location,
                ["p_Operation"] = request.Operation, // Just a workflow step number (90, 100, 110)
                ["p_Quantity"] = request.Quantity,
                ["p_ItemType"] = request.ItemType,
                ["p_User"] = request.User,
                ["p_Notes"] = request.Notes,
                ["p_TransactionType"] = transactionType // Based on user intent, NOT operation
            }
        );
        
        return result.IsSuccess 
            ? Result<bool>.Success(result.Value.IsSuccess)
            : Result<bool>.Failure(result.Error);
    }
    catch (Exception ex)
    {
        await LogErrorAsync(ex);
        return Result<bool>.Failure($"Failed to process inventory operation: {ex.Message}");
    }
}
```

---

## ?? Custom Prompts

All missing systems have corresponding custom prompts for implementation. The complete prompt library includes **52+ specialized prompts** covering:

### Foundation Systems (Prompts 21-24)
- **Result Pattern System** (? Complete)
- **Data Models Foundation** (? Complete)  
- **Dependency Injection Container** (? Complete)
- **Core Service Interfaces** (? Complete)

### Service Layer (Prompts 25-28)
- **Service Layer Implementation** - Business logic with MTM patterns
- **Database Service Layer** (? Complete) - Stored procedure only access
- **Application State Management** - Global application state
- **Configuration Service** - Settings and validation

### Infrastructure (Prompts 29-32)
- **Navigation Service** - MVVM navigation patterns
- **Theme System** - Resource management and theme switching
- **Repository Pattern** - Data access abstraction
- **Validation System** - Business rule enforcement

### Quality Assurance (Prompts 33-36)
- **Unit Testing Infrastructure** - Complete testing framework
- **Structured Logging** - Centralized logging throughout application
- **Caching Layer** - Performance-oriented caching
- **Security Infrastructure** - Authentication and authorization

### Database Operations (Prompts 37-52)
- **Core Database Operations** (37-42) - Creating, updating, validating procedures
- **Advanced Database Operations** (43-46) - Batch processing, reporting, performance
- **Specialized Database Operations** (47-50) - Migration, recovery, security audit
- **Maintenance & Optimization** (51-52) - Performance tuning, automated maintenance

See [exportable-customprompt.instruction.md](exportable-customprompt.instruction.md) for detailed prompts.

---

## ?? MTM Business Patterns

### Critical Transaction Type Logic
**IMPORTANT: TransactionType is determined by USER INTENT, NOT Operation numbers**

```csharp
// ? CORRECT - TransactionType based on user action
var transactionType = userAction switch
{
    "ADD_STOCK" => TransactionType.IN,         // User adding stock to inventory
    "REMOVE_STOCK" => TransactionType.OUT,     // User removing stock from inventory  
    "TRANSFER_STOCK" => TransactionType.TRANSFER, // User moving stock between locations
    _ => throw new ArgumentException("Invalid user action")
};

// ? WRONG - Do NOT determine TransactionType from Operation number
// Operations (90, 100, 110) are workflow steps, not transaction indicators
```

### MTM Data Conventions
- **Part IDs**: Always strings (e.g., "PART001", "ABC123")
- **Operations**: String numbers representing workflow steps ("90", "100", "110")
- **Quantities**: Integer values for all inventory operations
- **UI Positions**: 1-based indexing for user display
- **BatchNumbers**: String format with specific generation rules

### Database Security Enforcement
```csharp
// ? REQUIRED - All database operations via stored procedures
var result = await _databaseService.ExecuteStoredProcedureAsync<T>(
    "procedure_name",
    parameters
);

// ? PROHIBITED - Direct SQL in application code
// var sql = "SELECT * FROM table WHERE id = @id"; // Security violation!
```

---

## ??? Database Security Requirements

### CRITICAL DATABASE RULE
**ALL database operations MUST use stored procedures - ZERO hard-coded SQL allowed**

### File Organization
- **Production Files** (`Database_Files/`) - **READ-ONLY** - Current production state
- **Development Files** (`Development/Database_Files/`) - **EDITABLE** - All development work

### Security Patterns
```csharp
// Input validation in stored procedures
DELIMITER $$
CREATE PROCEDURE example_procedure(
    IN p_PartID VARCHAR(50),
    IN p_Quantity INT,
    OUT p_Status INT,
    OUT p_ErrorMsg VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET p_Status = -1;
        SET p_ErrorMsg = 'Database error occurred';
        ROLLBACK;
    END;

    -- Validate inputs
    IF p_PartID IS NULL OR p_PartID = '' THEN
        SET p_Status = 1;
        SET p_ErrorMsg = 'PartID cannot be empty';
        LEAVE example_procedure;
    END IF;

    IF p_Quantity <= 0 THEN
        SET p_Status = 2;
        SET p_ErrorMsg = 'Quantity must be positive';
        LEAVE example_procedure;
    END IF;

    START TRANSACTION;
    
    -- Business logic here
    
    COMMIT;
    SET p_Status = 0;
    SET p_ErrorMsg = '';
END$$
DELIMITER ;
```

---

## ?? Maintenance Instructions

### When Adding/Updating Systems

1. **Update This README**: Add new system to the "Available Systems" table
2. **Update Custom Prompts**: Add corresponding prompt in `exportable-customprompt.instruction.md`
3. **Update Dependencies**: Modify NuGet package list if needed
4. **Update Examples**: Add usage examples for new systems
5. **Version Documentation**: Update system compatibility information

### Synchronization with Main Project

When systems are updated in the main MTM WIP Application:

1. **Copy Updated Files**: Replace corresponding files in Exportable folder
2. **Remove Framework Dependencies**: Strip out Avalonia/ReactiveUI specific code
3. **Update Documentation**: Reflect changes in README and custom prompts
4. **Test Integration**: Verify systems work in standalone scenarios
5. **Update Version**: Increment version numbers if applicable

### Quality Assurance

Before releasing exportable systems:

1. **Compile Check**: Ensure all systems compile independently
2. **Dependency Verification**: Confirm NuGet dependencies are minimal
3. **Framework Agnostic**: Remove UI framework specific code
4. **Documentation Update**: Ensure all documentation is current
5. **Example Testing**: Verify all code examples work correctly
6. **Security Validation**: Confirm no hard-coded SQL or security issues

---

## ?? Version History

| Version | Date | Changes | Systems Added/Updated |
|---------|------|---------|----------------------|
| 2.0.0 | 2025-01-27 | Major update with database service and MTM patterns | Database Service, Core Models, Service Interfaces |
| 1.5.0 | 2025-01-27 | Added comprehensive database operations prompts | 16 new database operation prompts (37-52) |
| 1.1.0 | 2025-01-27 | Added missing systems prompts | 16 core system prompts (21-36) |
| 1.0.0 | 2025-01-27 | Initial exportable package | Error Handling, Logging, Configuration |

---

## ?? Support

For questions about integrating these systems:

1. Check the [Custom Prompts](exportable-customprompt.instruction.md) for implementation guidance
2. Review the implementation examples above
3. Refer to the original MTM WIP Application for reference implementations
4. Use the provided prompts with GitHub Copilot for step-by-step implementation
5. Contact the project maintainer for assistance

---

## ?? Important Security Notes

- **Database Operations**: Only stored procedures are allowed - NO exceptions
- **Error Handling**: All errors must be logged through the provided error handling system  
- **Configuration**: Never store sensitive data in plain text - use secure configuration methods
- **Input Validation**: Always validate inputs both in application code and stored procedures
- **File Organization**: Respect READ-ONLY status of production database files

---

**Note**: This package is maintained in sync with the MTM WIP Application project. When systems are updated in the main project, corresponding updates should be made to this exportable package following the maintenance instructions above.

The exportable systems follow clean architecture principles and can be integrated into any .NET application regardless of UI framework (Console, Web API, WPF, Avalonia, Blazor, etc.).