using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Common;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Caching.Memory;
using MTM.Core.Services;
using MTM.Models;
using ConfigurationProvider = MTM.Core.Services.IConfigurationProvider;

namespace MTM.Core.Extensions
{
    /// <summary>
    /// Extension methods for registering MTM Core Services with dependency injection.
    /// Framework-agnostic implementation compatible with any .NET application.
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Adds all MTM Core Services to the service collection.
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The configuration instance</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddMTMCoreServices(this IServiceCollection services, IConfiguration configuration)
        {
            // Foundation Services (IMPLEMENTED)
            services.AddSingleton<IConfigurationService>(provider => 
                new ConfigurationService(configuration));
            
            services.AddScoped<IDatabaseService>(provider =>
            {
                var connectionString = configuration.GetConnectionString("DefaultConnection") 
                    ?? throw new InvalidOperationException("DefaultConnection string not found in configuration");
                var commandTimeout = configuration.GetValue<int>("Database:CommandTimeout", 30);
                var maxRetryAttempts = configuration.GetValue<int>("Database:MaxRetryAttempts", 3);
                
                return new DatabaseService(connectionString, commandTimeout, maxRetryAttempts);
            });

            // Service Layer (TO BE IMPLEMENTED - placeholders)
            // services.AddScoped<IInventoryService, InventoryService>();
            // services.AddScoped<IUserService, UserService>();
            
            // Infrastructure Services (TO BE IMPLEMENTED - placeholders)
            // services.AddSingleton<ICacheService, CacheService>();
            // services.AddScoped<IValidationService, ValidationService>();
            // services.AddScoped<IApplicationStateService, ApplicationStateService>();
            
            // Quality Assurance Services (TO BE IMPLEMENTED - placeholders)
            // services.AddSingleton<ILoggingService, LoggingService>();
            // services.AddScoped<ISecurityService, SecurityService>();

            // Database Connection Factory
            services.AddScoped<IDbConnectionFactory>(provider =>
            {
                var connectionString = configuration.GetConnectionString("DefaultConnection") 
                    ?? throw new InvalidOperationException("DefaultConnection string not found in configuration");
                return new DatabaseConnectionFactory(connectionString);
            });

            return services;
        }

        /// <summary>
        /// Adds MTM Core Services with custom database connection factory.
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The configuration instance</param>
        /// <param name="connectionFactory">The database connection factory</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddMTMCoreServices(this IServiceCollection services, 
            IConfiguration configuration, 
            IDbConnectionFactory connectionFactory)
        {
            // Add core services
            services.AddMTMCoreServices(configuration);

            // Add database connection factory
            services.AddSingleton(connectionFactory);

            // Configure error handling with database support
            LoggingUtility.SetConnectionFactory(connectionFactory);

            return services;
        }

        /// <summary>
        /// Adds MTM Core Services for development environment.
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The configuration instance</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddMTMCoreServicesForDevelopment(this IServiceCollection services, IConfiguration configuration)
        {
            // Add core services
            services.AddMTMCoreServices(configuration);

            // Configure for development
            ErrorHandlingConfiguration.ConfigureForDevelopment();

            return services;
        }

        /// <summary>
        /// Adds MTM Core Services for production environment.
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <param name="configuration">The configuration instance</param>
        /// <param name="connectionFactory">The database connection factory</param>
        /// <returns>The service collection for chaining</returns>
        public static IServiceCollection AddMTMCoreServicesForProduction(this IServiceCollection services, 
            IConfiguration configuration, 
            IDbConnectionFactory connectionFactory)
        {
            // Add core services with database support
            services.AddMTMCoreServices(configuration, connectionFactory);

            // Configure for production
            ErrorHandlingConfiguration.ConfigureForProduction();

            return services;
        }

        /// <summary>
        /// Configures error handling system.
        /// </summary>
        private static void ConfigureErrorHandling(IServiceCollection services, IConfiguration configuration)
        {
            // Create configuration provider for error handling
            var configProvider = new ServiceConfigurationProvider(configuration);
            
            // Configure error handling
            services.AddSingleton<ConfigurationProvider>(configProvider);
            
            // Add post-configure action to initialize error handling
            services.AddHostedService<ErrorHandlingInitializationService>();
        }

        /// <summary>
        /// Configures logging system.
        /// </summary>
        private static void ConfigureLogging(IServiceCollection services, IConfiguration configuration)
        {
            services.AddLogging(builder =>
            {
                builder.AddConfiguration(configuration.GetSection("Logging"));
                builder.AddConsole();
                
                // Add file logging if configured
                var fileLoggingEnabled = configuration.GetValue<bool>("Logging:File:Enable");
                if (fileLoggingEnabled)
                {
                    // TODO: Add file logging provider
                    // builder.AddFile(configuration.GetSection("Logging:File"));
                }
            });
        }
    }

    /// <summary>
    /// Configuration provider implementation for integrating with Microsoft.Extensions.Configuration.
    /// </summary>
    internal class ServiceConfigurationProvider : ConfigurationProvider
    {
        private readonly IConfiguration _configuration;

        public ServiceConfigurationProvider(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string? GetValue(string key)
        {
            return _configuration[key];
        }

        public bool? GetBoolValue(string key)
        {
            var value = _configuration[key];
            return bool.TryParse(value, out var result) ? result : null;
        }

        public int? GetIntValue(string key)
        {
            var value = _configuration[key];
            return int.TryParse(value, out var result) ? result : null;
        }
    }

    /// <summary>
    /// Hosted service for initializing error handling on application startup.
    /// </summary>
    internal class ErrorHandlingInitializationService : IHostedService
    {
        private readonly ConfigurationProvider _configProvider;
        private readonly IDbConnectionFactory? _connectionFactory;
        private readonly ILogger<ErrorHandlingInitializationService> _logger;

        public ErrorHandlingInitializationService(
            ConfigurationProvider configProvider, 
            ILogger<ErrorHandlingInitializationService> logger,
            IDbConnectionFactory? connectionFactory = null)
        {
            _configProvider = configProvider;
            _connectionFactory = connectionFactory;
            _logger = logger;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Initializing MTM error handling system...");

            var success = ErrorHandlingInitializer.Initialize(_configProvider, _connectionFactory);
            
            if (success)
            {
                _logger.LogInformation("MTM error handling system initialized successfully");
            }
            else
            {
                _logger.LogWarning("MTM error handling system initialization completed with warnings");
            }

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Shutting down MTM error handling system...");
            ErrorHandlingInitializer.Shutdown();
            return Task.CompletedTask;
        }
    }

    /// <summary>
    /// TODO: Placeholder service implementations.
    /// Implement these services using the custom prompts:
    /// 
    /// - ConfigurationService (Prompt 28)
    /// - ApplicationStateService (Prompt 27)
    /// - CacheService (Prompt 35)
    /// - ValidationService (Prompt 32)
    /// - UserService (Prompt 25)
    /// - DatabaseService (Prompt 26)
    /// 
    /// See exportable-customprompt.instruction.md for detailed implementation prompts.
    /// </summary>
    
    // Placeholder implementations - replace with actual implementations
    internal class ConfigurationService : IConfigurationService
    {
        private readonly IConfiguration _configuration;

        public ConfigurationService(IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public string? GetValue(string key) => _configuration[key];

        public T? GetValue<T>(string key) => _configuration.GetValue<T>(key);

        public T GetValue<T>(string key, T defaultValue) => _configuration.GetValue<T>(key, defaultValue);

        public string? GetConnectionString(string name) => _configuration.GetConnectionString(name);

        public T? GetSection<T>(string sectionName) where T : class, new()
        {
            var section = _configuration.GetSection(sectionName);
            if (!section.Exists()) return null;

            var result = new T();
            section.Bind(result);
            return result;
        }

        public Result ValidateConfiguration()
        {
            try
            {
                // Basic validation - expand this in full implementation
                var connectionString = GetConnectionString("DefaultConnection");
                if (string.IsNullOrWhiteSpace(connectionString))
                {
                    return Result.Failure("DefaultConnection string is missing or empty");
                }

                return Result.Success();
            }
            catch (Exception ex)
            {
                return Result.Failure($"Configuration validation failed: {ex.Message}");
            }
        }

        public async Task<Result> ReloadConfigurationAsync()
        {
            try
            {
                // TODO: Implement configuration reload logic
                await Task.CompletedTask;
                return Result.Success();
            }
            catch (Exception ex)
            {
                return Result.Failure($"Configuration reload failed: {ex.Message}");
            }
        }
    }
}