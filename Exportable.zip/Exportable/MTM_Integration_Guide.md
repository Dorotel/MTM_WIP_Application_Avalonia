# MTM Integration Guide

This guide provides step-by-step instructions for integrating MTM Core Systems into any C# application, regardless of framework (Console, Web API, WPF, Avalonia, Blazor, etc.).

## ?? Quick Start (5 Minutes)

### 1. Copy Core Files
Copy these folders from `Exportable/` to your project:
```
YourProject/
??? Models/           # MTM data models and Result pattern
??? Services/         # Core service interfaces and implementations
??? Configuration/    # Configuration management
??? Extensions/       # Dependency injection setup
```

### 2. Install NuGet Packages
```powershell
# Required for all integrations
dotnet add package Microsoft.Extensions.DependencyInjection
dotnet add package Microsoft.Extensions.Configuration
dotnet add package Microsoft.Extensions.Configuration.Json

# Required for database operations
dotnet add package Dapper
dotnet add package MySql.Data

# Required for error handling
dotnet add package Microsoft.Extensions.Logging
```

### 3. Add Configuration
Create `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=your_db;Uid=user;Pwd=password;"
  },
  "Database": {
    "CommandTimeout": 30,
    "MaxRetryAttempts": 3
  }
}
```

### 4. Register Services
In `Program.cs`:
```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using MTM.Core.Extensions;

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json")
    .Build();

var services = new ServiceCollection();
services.AddMTMCoreServices(configuration);

var serviceProvider = services.BuildServiceProvider();
```

### 5. Use Services
```csharp
var databaseService = serviceProvider.GetRequiredService<IDatabaseService>();

// Test connection
var connectionTest = await databaseService.TestConnectionAsync();
if (connectionTest.IsSuccess && connectionTest.Value)
{
    Console.WriteLine("Database connected successfully!");
}
```

---

## ?? Framework-Specific Integration

### Console Application
```csharp
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using MTM.Core.Extensions;

class Program
{
    static async Task Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                services.AddMTMCoreServices(context.Configuration);
            })
            .Build();

        var databaseService = host.Services.GetRequiredService<IDatabaseService>();
        
        // Your application logic here
        var result = await databaseService.ExecuteStoredProcedureAsync<dynamic>(
            "your_procedure_name",
            new Dictionary<string, object> { ["p_Parameter"] = "value" }
        );

        await host.RunAsync();
    }
}
```

### ASP.NET Core Web API
```csharp
// Program.cs
using MTM.Core.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add MTM services
builder.Services.AddMTMCoreServices(builder.Configuration);

// Add controllers
builder.Services.AddControllers();

var app = builder.Build();

app.UseRouting();
app.MapControllers();

app.Run();

// Controllers/InventoryController.cs
[ApiController]
[Route("api/[controller]")]
public class InventoryController : ControllerBase
{
    private readonly IDatabaseService _databaseService;

    public InventoryController(IDatabaseService databaseService)
    {
        _databaseService = databaseService;
    }

    [HttpGet("{partId}")]
    public async Task<ActionResult<InventoryItem>> GetInventory(string partId)
    {
        var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
            "inv_inventory_Get_ByPartID",
            new Dictionary<string, object> { ["p_PartID"] = partId }
        );

        if (!result.IsSuccess)
            return BadRequest(result.Error);

        var item = result.Value.FirstOrDefault();
        return item != null ? Ok(item) : NotFound();
    }
}
```

### WPF Application
```csharp
// App.xaml.cs
public partial class App : Application
{
    public IServiceProvider ServiceProvider { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false)
            .Build();

        var services = new ServiceCollection();
        services.AddMTMCoreServices(configuration);
        services.AddTransient<MainWindow>();

        ServiceProvider = services.BuildServiceProvider();

        var mainWindow = ServiceProvider.GetRequiredService<MainWindow>();
        mainWindow.Show();

        base.OnStartup(e);
    }
}

// MainWindow.xaml.cs
public partial class MainWindow : Window
{
    private readonly IDatabaseService _databaseService;

    public MainWindow(IDatabaseService databaseService)
    {
        InitializeComponent();
        _databaseService = databaseService;
    }

    private async void LoadData_Click(object sender, RoutedEventArgs e)
    {
        var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
            "inv_inventory_Get_All",
            null
        );

        if (result.IsSuccess)
        {
            DataGrid.ItemsSource = result.Value;
        }
    }
}
```

### Avalonia Application
```csharp
// Program.cs
class Program
{
    public static void Main(string[] args) => BuildAvaloniaApp()
        .StartWithClassicDesktopLifetime(args);

    public static AppBuilder BuildAvaloniaApp()
        => AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .LogToTrace();
}

// App.axaml.cs
public partial class App : Application
{
    public IServiceProvider ServiceProvider { get; private set; }

    public override void OnFrameworkInitializationCompleted()
    {
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .Build();

        var services = new ServiceCollection();
        services.AddMTMCoreServices(configuration);
        services.AddTransient<MainWindow>();

        ServiceProvider = services.BuildServiceProvider();

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            desktop.MainWindow = ServiceProvider.GetRequiredService<MainWindow>();
        }

        base.OnFrameworkInitializationCompleted();
    }
}
```

### Blazor Server Application
```csharp
// Program.cs
using MTM.Core.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

// Add MTM services
builder.Services.AddMTMCoreServices(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline
app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();

// Pages/Inventory.razor
@page "/inventory"
@inject IDatabaseService DatabaseService

<h3>Inventory Management</h3>

@if (inventoryItems != null)
{
    <table class="table">
        <thead>
            <tr>
                <th>Part ID</th>
                <th>Location</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody>
            @foreach (var item in inventoryItems)
            {
                <tr>
                    <td>@item.PartID</td>
                    <td>@item.Location</td>
                    <td>@item.Quantity</td>
                </tr>
            }
        </tbody>
    </table>
}

@code {
    private List<InventoryItem>? inventoryItems;

    protected override async Task OnInitializedAsync()
    {
        var result = await DatabaseService.ExecuteStoredProcedureAsync<InventoryItem>(
            "inv_inventory_Get_All",
            null
        );

        if (result.IsSuccess)
        {
            inventoryItems = result.Value;
        }
    }
}
```

---

## ?? Advanced Configuration

### Environment-Specific Configuration
```csharp
// For different environments
var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production";

var configuration = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json", optional: false)
    .AddJsonFile($"appsettings.{environment}.json", optional: true)
    .AddEnvironmentVariables()
    .Build();

if (environment == "Development")
{
    services.AddMTMCoreServicesForDevelopment(configuration);
}
else
{
    services.AddMTMCoreServices(configuration);
}
```

### Custom Database Provider
```csharp
// For SQL Server instead of MySQL
public class SqlServerDatabaseService : DatabaseService
{
    public SqlServerDatabaseService(string connectionString, int commandTimeout = 30, int maxRetryAttempts = 3)
        : base(connectionString, commandTimeout, maxRetryAttempts)
    {
    }

    protected override async Task<DbConnection> CreateConnectionAsync()
    {
        var connection = new SqlConnection(ConnectionString);
        await connection.OpenAsync();
        return connection;
    }

    protected override bool ShouldRetry(Exception ex)
    {
        if (ex is SqlException sqlEx)
        {
            return sqlEx.Number switch
            {
                1205 => true, // Deadlock victim
                -2 => true,   // Timeout
                2 => true,    // Network error
                _ => false
            };
        }
        return false;
    }
}

// Register custom service
services.AddScoped<IDatabaseService>(provider =>
{
    var connectionString = configuration.GetConnectionString("DefaultConnection");
    return new SqlServerDatabaseService(connectionString);
});
```

### Testing Configuration
```csharp
// For unit testing
public class TestStartup
{
    public void ConfigureServices(IServiceCollection services)
    {
        services.AddMTMCoreServicesForTesting();
        
        // Override with mock services
        services.AddScoped<IDatabaseService, MockDatabaseService>();
        services.AddSingleton<IConfigurationService, MockConfigurationService>();
    }
}

public class MockDatabaseService : IDatabaseService
{
    public async Task<Result<List<T>>> ExecuteStoredProcedureAsync<T>(
        string procedureName, 
        Dictionary<string, object>? parameters = null, 
        CancellationToken cancellationToken = default)
    {
        // Return mock data
        await Task.Delay(50, cancellationToken);
        return Result<List<T>>.Success(new List<T>());
    }
    
    // Implement other interface methods...
}
```

---

## ?? Security Configuration

### Connection String Encryption
```csharp
public class SecureConfigurationService : IConfigurationService
{
    private readonly IConfiguration _configuration;
    private readonly IDataProtector _protector;

    public SecureConfigurationService(IConfiguration configuration, IDataProtectionProvider provider)
    {
        _configuration = configuration;
        _protector = provider.CreateProtector("ConnectionStrings");
    }

    public string? GetConnectionString(string name)
    {
        var encryptedConnectionString = _configuration.GetConnectionString(name);
        if (string.IsNullOrEmpty(encryptedConnectionString))
            return null;

        try
        {
            return _protector.Unprotect(encryptedConnectionString);
        }
        catch
        {
            // Fall back to plain text for development
            return encryptedConnectionString;
        }
    }
}
```

### Role-Based Service Access
```csharp
public class SecureDatabaseService : IDatabaseService
{
    private readonly IDatabaseService _inner;
    private readonly ISecurityService _securityService;

    public SecureDatabaseService(IDatabaseService inner, ISecurityService securityService)
    {
        _inner = inner;
        _securityService = securityService;
    }

    public async Task<Result<List<T>>> ExecuteStoredProcedureAsync<T>(
        string procedureName, 
        Dictionary<string, object>? parameters = null, 
        CancellationToken cancellationToken = default)
    {
        // Check permissions before executing
        var hasPermission = await _securityService.ValidatePermissionAsync(
            GetCurrentUserId(), 
            $"database.{procedureName}", 
            cancellationToken);

        if (!hasPermission.IsSuccess || !hasPermission.Value)
        {
            return Result<List<T>>.Failure("Insufficient permissions");
        }

        return await _inner.ExecuteStoredProcedureAsync<T>(procedureName, parameters, cancellationToken);
    }
}
```

---

## ?? Monitoring and Logging

### Performance Monitoring
```csharp
public class MonitoredDatabaseService : IDatabaseService
{
    private readonly IDatabaseService _inner;
    private readonly ILogger<MonitoredDatabaseService> _logger;

    public async Task<Result<List<T>>> ExecuteStoredProcedureAsync<T>(
        string procedureName, 
        Dictionary<string, object>? parameters = null, 
        CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        
        try
        {
            _logger.LogInformation("Executing stored procedure: {ProcedureName}", procedureName);
            
            var result = await _inner.ExecuteStoredProcedureAsync<T>(procedureName, parameters, cancellationToken);
            
            stopwatch.Stop();
            _logger.LogInformation("Stored procedure {ProcedureName} completed in {ElapsedMs}ms", 
                procedureName, stopwatch.ElapsedMilliseconds);
            
            return result;
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex, "Stored procedure {ProcedureName} failed after {ElapsedMs}ms", 
                procedureName, stopwatch.ElapsedMilliseconds);
            throw;
        }
    }
}
```

### Health Checks
```csharp
// Add to ASP.NET Core applications
services.AddHealthChecks()
    .AddCheck<DatabaseHealthCheck>("database");

public class DatabaseHealthCheck : IHealthCheck
{
    private readonly IDatabaseService _databaseService;

    public DatabaseHealthCheck(IDatabaseService databaseService)
    {
        _databaseService = databaseService;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var result = await _databaseService.TestConnectionAsync(cancellationToken);
            
            return result.IsSuccess && result.Value
                ? HealthCheckResult.Healthy("Database connection is healthy")
                : HealthCheckResult.Unhealthy($"Database connection failed: {result.Error}");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy($"Database health check failed: {ex.Message}");
        }
    }
}
```

---

## ?? Testing Integration

### Unit Testing Setup
```csharp
[TestClass]
public class InventoryServiceTests
{
    private Mock<IDatabaseService> _mockDatabaseService;
    private InventoryService _inventoryService;

    [TestInitialize]
    public void Setup()
    {
        _mockDatabaseService = new Mock<IDatabaseService>();
        _inventoryService = new InventoryService(_mockDatabaseService.Object);
    }

    [TestMethod]
    public async Task GetInventoryItem_WhenItemExists_ReturnsItem()
    {
        // Arrange
        var partId = "TEST001";
        var expectedItem = new InventoryItem { PartID = partId, Quantity = 10 };
        
        _mockDatabaseService
            .Setup(x => x.ExecuteStoredProcedureAsync<InventoryItem>(
                "inv_inventory_Get_ByPartID",
                It.IsAny<Dictionary<string, object>>(),
                It.IsAny<CancellationToken>()))
            .ReturnsAsync(Result<List<InventoryItem>>.Success(new List<InventoryItem> { expectedItem }));

        // Act
        var result = await _inventoryService.GetInventoryItemAsync(partId);

        // Assert
        Assert.IsTrue(result.IsSuccess);
        Assert.AreEqual(partId, result.Value.PartID);
    }
}
```

### Integration Testing
```csharp
[TestClass]
public class DatabaseIntegrationTests
{
    private IDatabaseService _databaseService;

    [TestInitialize]
    public void Setup()
    {
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("appsettings.test.json")
            .Build();

        var services = new ServiceCollection();
        services.AddMTMDatabaseServices(configuration);
        
        var serviceProvider = services.BuildServiceProvider();
        _databaseService = serviceProvider.GetRequiredService<IDatabaseService>();
    }

    [TestMethod]
    public async Task DatabaseConnection_ShouldBeHealthy()
    {
        var result = await _databaseService.TestConnectionAsync();
        
        Assert.IsTrue(result.IsSuccess);
        Assert.IsTrue(result.Value);
    }
}
```

---

## ?? Migration from Existing Code

### Replacing Direct SQL Calls
```csharp
// OLD CODE (INSECURE)
// var sql = "SELECT * FROM inv_inventory WHERE PartID = @partId";
// var result = await connection.QueryAsync<InventoryItem>(sql, new { partId });

// NEW CODE (SECURE)
var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
    "inv_inventory_Get_ByPartID",
    new Dictionary<string, object> { ["p_PartID"] = partId }
);
```

### Replacing Legacy Error Handling
```csharp
// OLD CODE
// try
// {
//     var data = GetData();
//     return data;
// }
// catch (Exception ex)
// {
//     Logger.LogError(ex.Message);
//     return null;
// }

// NEW CODE
public async Task<Result<Data>> GetDataAsync()
{
    try
    {
        var result = await _databaseService.ExecuteStoredProcedureAsync<Data>(
            "data_Get_All",
            null
        );
        
        return result.IsSuccess
            ? Result<Data>.Success(result.Value)
            : Result<Data>.Failure(result.Error);
    }
    catch (Exception ex)
    {
        return Result<Data>.Failure($"Data retrieval failed: {ex.Message}");
    }
}
```

---

## ?? Additional Resources

### Useful Patterns
- [Database Operations Guide](Database_Operations_Guide.md) - Complete database patterns
- [Custom Prompts](exportable-customprompt.instruction.md) - Implementation prompts for missing systems
- [Main README](README.md) - Complete system overview

### NuGet Package References
```xml
<!-- Core packages for all applications -->
<PackageReference Include="Microsoft.Extensions.DependencyInjection" Version="8.0.0" />
<PackageReference Include="Microsoft.Extensions.Configuration" Version="8.0.0" />
<PackageReference Include="Microsoft.Extensions.Configuration.Json" Version="8.0.0" />

<!-- Database packages -->
<PackageReference Include="Dapper" Version="2.1.24" />
<PackageReference Include="MySql.Data" Version="8.2.0" />

<!-- Logging packages -->
<PackageReference Include="Microsoft.Extensions.Logging" Version="8.0.0" />
<PackageReference Include="Microsoft.Extensions.Logging.Console" Version="8.0.0" />

<!-- Testing packages -->
<PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.8.0" />
<PackageReference Include="MSTest.TestAdapter" Version="3.1.1" />
<PackageReference Include="MSTest.TestFramework" Version="3.1.1" />
<PackageReference Include="Moq" Version="4.20.69" />
```

### Common Configuration Templates
See the complete `appsettings.json` template in the [README](README.md#step-4-initialize-configuration) section.

---

**Success!** You now have MTM Core Systems integrated into your application with proper security, error handling, and database access patterns.