# MTM Core Systems - Custom Implementation Prompts

This file contains custom prompts for implementing all MTM core systems into any C# application. These prompts are designed to be used with GitHub Copilot or similar AI coding assistants.

## ?? Table of Contents

- [Foundation Systems (Prompts 21-24)](#foundation-systems-prompts-21-24)
- [Service Layer (Prompts 25-28)](#service-layer-prompts-25-28)
- [Infrastructure (Prompts 29-32)](#infrastructure-prompts-29-32)
- [Quality Assurance (Prompts 33-36)](#quality-assurance-prompts-33-36)
- [Database Operations (Prompts 37-52)](#database-operations-prompts-37-52)
- [Implementation Workflow](#implementation-workflow)
- [Integration Examples](#integration-examples)

---

## ??? Foundation Systems (Prompts 21-24)

### 21. Implement Result Pattern System ? COMPLETE

**Persona:** Data Modeling Copilot + Application Logic Copilot

**Status:** ? **IMPLEMENTED** - Available in `Models/Result.cs`

**Prompt:**
```
Create the Result<T> pattern infrastructure for .NET 8 applications following modern C# patterns.
Implement Models/Result.cs with Success/Failure states, error messages, and implicit operators.
Include static factory methods Success<T>(T value) and Failure(string error), IsSuccess and IsFailure properties,
proper equality comparison, and integration patterns for async service methods. Ensure compatibility with
any .NET application framework and comprehensive XML documentation.
```

**Integration Example:**
```csharp
public async Task<Result<User>> GetUserAsync(string userId)
{
    try
    {
        var user = await _repository.GetByIdAsync(userId);
        return user != null 
            ? Result<User>.Success(user)
            : Result<User>.Failure("User not found");
    }
    catch (Exception ex)
    {
        return Result<User>.Failure($"Database error: {ex.Message}");
    }
}
```

---

### 22. Create Data Models Foundation ? COMPLETE

**Persona:** Data Modeling Copilot

**Status:** ? **IMPLEMENTED** - Available in `Models/CoreModels.cs`

**Prompt:**
```
Create the complete Models namespace foundation for .NET 8 application with MTM-specific data entities.
Generate Models/CoreModels.cs with User, InventoryItem, InventoryTransaction, and supporting entities.
Include proper validation attributes, MTM business patterns (Part IDs as strings, Operations as string numbers),
TransactionType enum (IN/OUT/TRANSFER), and comprehensive XML documentation. Ensure compatibility with 
Entity Framework Core and other ORMs while following MTM data conventions.
```

**Integration Example:**
```csharp
public class InventoryItem
{
    public string PartID { get; set; } = string.Empty;
    public string Operation { get; set; } = string.Empty; // "90", "100", "110"
    public int Quantity { get; set; }
    public TransactionType TransactionType { get; set; } // Determined by user intent
}
```

---

### 23. Setup Dependency Injection Container ? COMPLETE

**Persona:** Application Logic Copilot + Configuration Wizard Copilot

**Status:** ? **IMPLEMENTED** - Available in `Extensions/ServiceCollectionExtensions.cs`

**Prompt:**
```
Configure Microsoft.Extensions.DependencyInjection for .NET 8 application with proper service registration.
Create Extensions/ServiceCollectionExtensions.cs with AddMTMCoreServices() method for registering all services.
Setup proper lifetime management (Singleton, Scoped, Transient), create service registration patterns for
repositories, services, and infrastructure components. Include development vs production service variants
and integration with logging and configuration services. Ensure compatibility with any .NET application type.
```

**Integration Example:**
```csharp
// In Program.cs
services.AddMTMCoreServices(configuration);

// Extension method
public static IServiceCollection AddMTMCoreServices(this IServiceCollection services, IConfiguration configuration)
{
    services.AddScoped<IDatabaseService, DatabaseService>();
    services.AddSingleton<IConfigurationService, ConfigurationService>();
    return services;
}
```

---

### 24. Create Core Service Interfaces ? COMPLETE

**Persona:** Application Logic Copilot + Data Access Copilot

**Status:** ? **IMPLEMENTED** - Available in `Services/Interfaces/ICoreServices.cs`

**Prompt:**
```
Generate essential service interfaces for .NET 8 application following clean architecture patterns.
Create Services/Interfaces/ICoreServices.cs with IDatabaseService, IConfigurationService, IApplicationStateService,
and ICacheService. Include async methods returning Result<T> pattern, proper cancellation token support, 
and comprehensive XML documentation. Design interfaces to be framework-agnostic and suitable for dependency 
injection. Include stored procedure only patterns for database operations.
```

**Integration Example:**
```csharp
public interface IDatabaseService
{
    Task<Result<List<T>>> ExecuteStoredProcedureAsync<T>(
        string procedureName, 
        Dictionary<string, object>? parameters = null, 
        CancellationToken cancellationToken = default);
}
```

---

## ?? Service Layer (Prompts 25-28)

### 25. Implement Service Layer

**Persona:** Application Logic Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Implement complete service layer for .NET 8 application following clean architecture principles.
Create Services/InventoryService.cs implementing IInventoryService interface with full error handling,
async/await patterns, and Result<T> return types. Include comprehensive logging, proper validation,
dependency injection constructor, and integration with IDatabaseService using stored procedures only.
Follow MTM business patterns: TransactionType determined by user intent (not operation numbers),
Part IDs as strings, Operations as workflow step numbers. Add XML documentation and ensure 
proper separation of concerns between business logic and data access.
```

**Expected Output:**
- Complete service implementations with MTM patterns
- Error handling using Service_ErrorHandler integration
- Logging integration throughout service methods
- Repository pattern usage via IDatabaseService
- Business logic encapsulation with stored procedure calls

---

### 26. Create Database Service Layer ? COMPLETE

**Persona:** Data Access Copilot

**Status:** ? **IMPLEMENTED** - Available in `Services/DatabaseService.cs` (framework-agnostic version needed)

**Prompt:**
```
Create centralized database service layer with proper connection management for .NET 8 application.
Implement Services/DatabaseService.cs with IDatabaseService interface including connection pooling,
transaction management, and async operations. CRITICAL: Enforce "stored procedures only" rule with
security validation preventing direct SQL execution. Include connection string management from configuration,
retry policies for connection failures, proper disposal patterns, and support for stored procedures with
status output parameters. Add comprehensive error handling and logging integration.
```

**Integration Example:**
```csharp
// ENFORCED: Only stored procedures allowed
var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
    "inv_inventory_Get_ByPartID",
    new Dictionary<string, object> { ["p_PartID"] = partId }
);
```

---

### 27. Setup Application State Management

**Persona:** Application Logic Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Create global application state service for .NET 8 application with proper encapsulation.
Implement Services/ApplicationStateService.cs with IApplicationStateService interface including
thread-safe state management, current user tracking, connection status monitoring, and settings
management. Include state change events, session management, and proper disposal patterns.
Support MTM-specific state like current user, selected operation numbers, and UI preferences.
Ensure compatibility with web, desktop, and console applications with different state persistence strategies.
```

**Expected Output:**
- Global state management with thread safety
- User session tracking and management
- Connection status monitoring with events
- Settings persistence and retrieval
- Cross-platform compatibility

---

### 28. Implement Configuration Service

**Persona:** Configuration Wizard Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Create configuration service to read and manage appsettings.json for .NET 8 application.
Implement Services/ConfigurationService.cs with IConfigurationService interface using
Microsoft.Extensions.Configuration. Include strongly-typed configuration classes for ErrorHandling,
Database, and Application sections. Add configuration validation with detailed error reporting,
environment-specific overrides (Development/Production), and real-time configuration reload support.
Include connection string security and proper error handling for missing or invalid configuration values.
```

**Expected Output:**
- Strongly-typed configuration management
- Validation with comprehensive error reporting
- Environment-specific configuration handling
- Hot reload capabilities for development
- Secure connection string management

---

## ??? Infrastructure (Prompts 29-32)

### 29. Create Navigation Service

**Persona:** Application Logic Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Implement navigation service for .NET 8 application with view-viewmodel mapping support.
Create Services/NavigationService.cs with INavigationService interface supporting parametrized
navigation, navigation history, and modal dialog management. Include view registration system,
automatic ViewModel instantiation with dependency injection, navigation events, and proper
cleanup. Design for compatibility with WPF, Avalonia, or other MVVM frameworks while maintaining
framework-agnostic core logic. Support MTM-specific navigation patterns like tab management
and context-sensitive navigation.
```

**Expected Output:**
- MVVM navigation patterns with view-model mapping
- Navigation history and back/forward support
- Modal dialog management
- Framework compatibility layer
- Dependency injection integration

---

### 30. Implement Theme System

**Persona:** UI/UX Design Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Create comprehensive theme system for .NET 8 application with resource management.
Generate Services/ThemeService.cs with IThemeService interface for theme management.
Include MTM purple brand color definitions (#4B45ED primary, #BA45ED accent, etc.),
dark/light mode variants, and theme switching capability. Create theme resource definitions
suitable for WPF, Avalonia, or other UI frameworks while maintaining framework-agnostic
core theme data. Include user preference persistence and real-time theme switching support.
```

**Expected Output:**
- MTM brand color palette management
- Theme switching logic with persistence
- Framework-agnostic theme definitions
- Resource management for UI frameworks
- User preference integration

---

### 31. Setup Repository Pattern

**Persona:** Data Access Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Implement data access abstraction layer with repository pattern for .NET 8 application.
Create Repositories/IRepository<T>.cs generic interface and Repositories/InventoryRepository.cs
specific implementation. Include unit of work pattern support, proper async operations with
Result<T> patterns, and integration with IDatabaseService for stored procedure execution.
Follow MTM patterns: all database access via stored procedures, proper transaction handling,
and comprehensive error handling. Ensure repository implementations are testable and support
dependency injection.
```

**Expected Output:**
- Generic repository pattern with MTM entities
- Specific repository implementations for core entities
- Unit of work pattern for transaction management
- Stored procedure integration via IDatabaseService
- Comprehensive error handling and logging

---

### 32. Create Validation System

**Persona:** Application Logic Copilot + Data Modeling Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Implement business rule validation system for .NET 8 application with comprehensive validation framework.
Create Services/ValidationService.cs with IValidationService interface using FluentValidation.
Include MTM-specific validation rules: Part ID format validation, operation number validation (string numbers),
quantity validation (positive integers), and business rule enforcement. Add custom validation attributes,
validation result patterns with detailed error messages, and integration with service layer.
Include localization support and context-aware validation for different user roles.
```

**Expected Output:**
- FluentValidation integration with MTM rules
- Custom validation attributes for MTM patterns
- Context-aware validation for different scenarios
- Localization support for error messages
- Service layer integration with validation

---

## ?? Quality Assurance (Prompts 33-36)

### 33. Create Unit Testing Infrastructure

**Persona:** Quality Assurance Copilot + Testing Specialist Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Setup comprehensive unit testing infrastructure for .NET 8 application with modern testing framework.
Create Tests/ project structure with xUnit, Moq, and FluentAssertions. Generate mock implementations for
IDatabaseService, IConfigurationService, and other core interfaces. Include test data builders for MTM
entities, testing utilities for async patterns, and testing fixtures for dependency injection scenarios.
Add repository pattern testing, service layer testing with proper Result<T> validation, and database
integration testing patterns. Include CI/CD integration configuration and test coverage reporting.
```

**Expected Output:**
- Complete test project with modern testing frameworks
- Mock implementations for all service interfaces
- Test data builders for MTM-specific entities
- Testing utilities for async and Result<T> patterns
- CI/CD integration and coverage reporting

---

### 34. Implement Structured Logging

**Persona:** DevOps Copilot + Application Logic Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Add centralized structured logging throughout .NET 8 application with Microsoft.Extensions.Logging.
Create Services/LoggingService.cs with ILoggingService interface for structured logging patterns.
Include performance logging, user action tracking, error correlation IDs, and log enrichment with
MTM-specific context (user, part IDs, operations). Add Serilog integration for advanced logging
capabilities, log file rotation, and structured JSON logging. Ensure integration with existing
Service_ErrorHandler and provide different logging levels for different environments.
```

**Expected Output:**
- Structured logging infrastructure with correlation IDs
- Microsoft.Extensions.Logging and Serilog integration
- Performance monitoring and user action tracking
- MTM-specific log enrichment
- Environment-specific logging configuration

---

### 35. Create Caching Layer

**Persona:** Performance Optimization Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Implement performance-oriented caching layer for .NET 8 application with Microsoft.Extensions.Caching.
Create Services/CacheService.cs with ICacheService interface supporting memory and distributed caching.
Include cache invalidation strategies for MTM entities (inventory items, user preferences),
expiration policies based on data volatility, and cache warming for frequently accessed data.
Ensure thread-safety, proper disposal, and integration with IConfigurationService for cache settings.
Include cache metrics, monitoring capabilities, and cache-aside pattern implementation.
```

**Expected Output:**
- Memory and distributed caching implementation
- MTM-specific cache invalidation strategies
- Performance monitoring and metrics
- Thread-safe operations with proper disposal
- Configuration-driven cache behavior

---

### 36. Setup Security Infrastructure

**Persona:** Security Specialist Copilot

**Status:** ?? **MISSING** - Implementation needed

**Prompt:**
```
Implement authentication, authorization, and secure connection management for .NET 8 application.
Create Services/SecurityService.cs with ISecurityService interface including user authentication
with secure credential storage, role-based authorization for MTM operations, and connection string
encryption. Add security headers, input sanitization patterns, and comprehensive audit logging.
Include security event tracking, session management, and integration with existing error handling.
Ensure compliance with security best practices and provide different security levels for different environments.
```

**Expected Output:**
- Authentication and authorization services
- Role-based access control for MTM operations
- Security audit logging and event tracking
- Input sanitization and security headers
- Session management with security compliance

---

## ??? Database Operations (Prompts 37-52)

### Core Database Operations (Prompts 37-42)

#### 37. Create New Stored Procedure

**Persona:** Database Architect Copilot  

**Prompt:**
```
Create a new stored procedure called `[procedure_name]` for [business purpose].  
Add the procedure to a new file called New_Stored_Procedures.sql (following development file organization).  
Include comprehensive error handling with p_Status and p_ErrorMsg output parameters.  
Follow MTM naming conventions: [category]_[entity]_[action]_[specifics].  
Add full documentation including purpose, parameters, return values, and usage examples.  
Include parameter validation, transaction management, and audit logging where appropriate.  
Ensure the procedure follows security requirements: validate all inputs, prevent SQL injection, and include proper error sanitization.
```

#### 38. Update Existing Stored Procedure

**Persona:** Database Architect Copilot  

**Prompt:**
```
Update an existing stored procedure `[procedure_name]` to [modification description].  
Create the updated version in Updated_Stored_Procedures.sql (following safe development practices).  
Document all changes using a change documentation template with before/after examples.  
Maintain backward compatibility unless explicitly noted as a breaking change.  
Update any corresponding application service methods if the interface changes.  
Include comprehensive testing notes and deployment instructions.
Add version comments and change history within the procedure.
```

#### 39. Create Database Service Method

**Persona:** Application Logic Copilot + Database Architect Copilot  

**Prompt:**
```
Create a service method in `[ServiceClass]` to call the stored procedure `[procedure_name]`.  
Use the IDatabaseService.ExecuteStoredProcedureAsync() pattern for consistency.  
Include comprehensive error handling with Service_ErrorHandler integration.  
Return Result<T> pattern for all operations with proper success/failure handling.  
Add XML documentation explaining the business purpose and parameters.  
Ensure the method follows MTM data patterns (Part ID strings, Operation numbers as workflow steps).  
Include parameter validation before calling the stored procedure.
```

#### 40. Validate Database Code Compliance

**Persona:** Security Auditor Copilot  

**Prompt:**
```
Audit all database-related code in [file/directory] for compliance with MTM database rules.  
Check for violations of the 'No Hard-Coded SQL' rule - identify any direct SQL statements.  
Verify proper use of IDatabaseService.ExecuteStoredProcedureAsync() methods.  
Ensure all development work is being done in appropriate development files.  
Verify all database interactions go through the approved service layer.  
Report any violations with specific file locations and recommended fixes.  
Include security assessment and recommendations for improvement.
```

#### 41. Convert Hard-Coded SQL to Stored Procedure

**Persona:** Database Architect Copilot + Application Logic Copilot  

**Prompt:**
```
Convert the hard-coded SQL statement `[SQL_CODE]` to use a stored procedure approach.  
Create the appropriate stored procedure in New_Stored_Procedures.sql with proper naming.  
Update the application code to call the new stored procedure using IDatabaseService.  
Ensure the conversion maintains the same functionality and performance.  
Add comprehensive error handling and parameter validation.  
Document the migration with before/after examples and performance comparisons.
Include testing procedures to verify the conversion is successful.
```

#### 42. Create Database Transaction Workflow

**Persona:** Database Architect Copilot  

**Prompt:**
```
Create a transaction workflow for [business process] that involves multiple stored procedures.  
Create coordinating stored procedures in New_Stored_Procedures.sql with proper naming.  
Use proper transaction management with BEGIN TRANSACTION, COMMIT, and ROLLBACK.  
Include rollback handling for any step failures with detailed error reporting.  
Call the following stored procedures in sequence: [procedure_list].  
Add comprehensive error handling and status tracking throughout the workflow.  
Ensure each step validates the previous step's success before proceeding.
Include audit logging for the complete transaction with timing information.
```

### Advanced Database Operations (Prompts 43-46)

#### 43. Create Batch Processing Stored Procedure

**Persona:** Database Architect Copilot  

**Prompt:**
```
Create a batch processing stored procedure `[procedure_name]` for [business purpose].  
Add to New_Stored_Procedures.sql following MTM standards and naming conventions.  
Process records in configurable batch sizes (default 1000 records) with progress tracking.  
Include progress tracking and resumption capability for long-running operations.  
Add loop counters and maximum execution limits to prevent runaway processes.  
Return status information including processed count, completion status, and timing information.  
Include cursor-based processing with proper memory management and cleanup.
Follow established patterns for batch processing with comprehensive error handling.
```

#### 44. Create Database Reporting Procedure

**Persona:** Database Architect Copilot + Reporting Specialist  

**Prompt:**
```
Create a reporting stored procedure `[procedure_name]` that generates [report_description].  
Add to New_Stored_Procedures.sql with full documentation and usage examples.  
Include date range parameters with proper validation and default values.  
Add optional filtering parameters for user, location, part, operation, etc.  
Return comprehensive result sets with calculated fields and aggregations.  
Include proper indexing hints and performance optimizations for large datasets.  
Add documentation explaining the business logic and calculations.
Ensure the procedure can handle large data volumes efficiently with pagination support.
```

#### 45. Create Data Validation Procedure

**Persona:** Database Architect Copilot + Data Validation Specialist  

**Prompt:**
```
Create a data validation stored procedure `[procedure_name]` that checks [validation_rules].  
Add to New_Stored_Procedures.sql with comprehensive documentation and usage scenarios.  
Return detailed validation results with specific error descriptions and affected record counts.  
Include options for validation-only mode and auto-correction mode.  
Add comprehensive logging of all validation failures with detailed context.  
Include rollback capability if validation fails during corrections.  
Return statistics on total records checked, errors found, and corrections made.
Follow established error handling patterns with proper status reporting.
```

#### 46. Debug Database Performance Issue

**Persona:** Database Performance Specialist Copilot  

**Prompt:**
```
Analyze the performance of stored procedure `[procedure_name]` and identify optimization opportunities.  
Create optimized version in Updated_Stored_Procedures.sql with performance improvements.  
Review the execution plan and identify slow queries or missing indexes.  
Suggest improvements for cursor usage, joins, and data access patterns.  
Recommend index additions or modifications with impact analysis.  
Check for parameter sniffing issues and suggest solutions.  
Provide before/after performance comparisons with benchmarking data.
Ensure optimizations maintain data integrity and business logic correctness.
```

### Specialized Database Operations (Prompts 47-50)

#### 47. Create Migration Stored Procedure

**Persona:** Database Architect Copilot + Migration Specialist  

**Prompt:**
```
Create a data migration stored procedure `[procedure_name]` for [migration_purpose].  
Add to New_Stored_Procedures.sql with full documentation and deployment instructions.  
Include comprehensive backup and rollback capabilities with validation.  
Add progress tracking and status reporting throughout the migration process.  
Include data validation before, during, and after migration with detailed reporting.  
Implement resumption capability for large migrations with checkpoint support.  
Add comprehensive logging of all migration steps and any issues encountered.  
Include pre-migration checks to validate system readiness and prerequisites.
Follow MTM transaction safety patterns with comprehensive error handling.
```

#### 48. Create Emergency Data Recovery Procedure

**Persona:** Database Architect Copilot + Disaster Recovery Specialist  

**Prompt:**
```
Create an emergency data recovery stored procedure `[procedure_name]` for [recovery_scenario].  
Add to New_Stored_Procedures.sql with emergency deployment notes and prerequisites.  
Include comprehensive data validation and integrity checking throughout recovery.  
Add detailed logging of all recovery operations with timestamp tracking.  
Include rollback capabilities if recovery fails with detailed failure analysis.  
Provide detailed status reporting and progress tracking with completion estimates.  
Include verification steps to confirm successful recovery with data integrity checks.  
Add emergency stop functionality for critical situations with safe abort procedures.
Document all prerequisites and recovery steps with step-by-step instructions.
```

#### 49. Security Audit Database Procedures

**Persona:** Security Auditor Copilot  

**Prompt:**
```
Conduct a comprehensive security audit of stored procedure `[procedure_name]`.  
Check for SQL injection vulnerabilities in dynamic SQL construction.  
Verify proper parameter validation and sanitization for all inputs.  
Ensure sensitive data is properly protected and not exposed in error messages.  
Check for privilege escalation possibilities and unauthorized data access.  
Verify proper error handling that doesn't expose sensitive information.  
Ensure audit logging is comprehensive and tamper-resistant.  
If fixes are needed, create updated version in Updated_Stored_Procedures.sql.  
Provide specific recommendations for security improvements with implementation examples.
```

#### 50. Create Access Control Procedure

**Persona:** Security Engineer Copilot + Database Architect Copilot  

**Prompt:**
```
Create a stored procedure `[procedure_name]` with role-based access control for [operation].  
Add to New_Stored_Procedures.sql with security documentation and role requirements.  
Include user permission checking against appropriate user roles tables.  
Add comprehensive audit logging of all access attempts (successful and failed).  
Return appropriate error messages for unauthorized access without exposing system details.  
Include parameter validation to prevent privilege escalation attempts.  
Add session validation and timeout checking with proper session management.  
Follow established security patterns for user management procedures with comprehensive validation.
```

### Maintenance & Optimization (Prompts 51-52)

#### 51. Optimize Slow Database Query

**Persona:** Database Performance Specialist Copilot  

**Prompt:**
```
Optimize the slow-performing section in stored procedure `[procedure_name]`: [slow_code_section].  
Create optimized version in Updated_Stored_Procedures.sql with performance improvements.  
Analyze the execution plan and identify bottlenecks with detailed analysis.  
Suggest index improvements or query restructuring with impact assessment.  
Consider replacing cursors with set-based operations where possible.  
Recommend partitioning strategies for large tables if applicable.  
Provide performance benchmarks before and after optimization with detailed metrics.  
Ensure optimizations don't affect data integrity or business logic correctness.
Include testing procedures to validate performance improvements.
```

#### 52. Create Database Maintenance Procedure

**Persona:** Database Architect Copilot + System Administrator  

**Prompt:**
```
Create a database maintenance stored procedure `[procedure_name]` for [maintenance_task].  
Add to New_Stored_Procedures.sql with maintenance documentation and scheduling guidelines.  
Include comprehensive status reporting and progress tracking with detailed logging.  
Add scheduling parameters and execution windows with configurable timeouts.  
Include automatic rollback if maintenance fails with detailed failure analysis.  
Add performance impact monitoring during execution with resource usage tracking.  
Include cleanup of temporary data and log files with space management.  
Provide detailed execution summaries and recommendations for optimization.
Follow established maintenance patterns with comprehensive error handling and recovery.
```

---

## ?? Implementation Workflow

### Phase 1: Foundation (Week 1)
Execute prompts 21-24 in order:
1. **Result Pattern (21)** ? - Core error handling (COMPLETE)
2. **Data Models (22)** ? - Entity foundation (COMPLETE)
3. **Dependency Injection (23)** ? - Service container (COMPLETE)
4. **Core Services (24)** ? - Service interfaces (COMPLETE)

### Phase 2: Service Layer (Week 2)
Execute prompts 25-28:
1. **Service Layer (25)** ?? - Business logic implementations
2. **Database Service (26)** ? - Data access (MOSTLY COMPLETE - needs framework-agnostic version)
3. **Application State (27)** ?? - State management
4. **Configuration Service (28)** ?? - Settings management

### Phase 3: Infrastructure (Week 3)
Execute prompts 29-32:
1. **Navigation Service (29)** ?? - UI navigation patterns
2. **Theme System (30)** ?? - UI theming and brand management
3. **Repository Pattern (31)** ?? - Data abstraction layer
4. **Validation System (32)** ?? - Business rules enforcement

### Phase 4: Quality Assurance (Week 4)
Execute prompts 33-36:
1. **Unit Testing (33)** ?? - Test infrastructure
2. **Structured Logging (34)** ?? - Monitoring and observability
3. **Caching Layer (35)** ?? - Performance optimization
4. **Security Infrastructure (36)** ?? - Security and compliance

### Phase 5: Database Operations (Ongoing)
Use prompts 37-52 as needed for database work:
- **Core Operations (37-42)** - Essential database development patterns
- **Advanced Operations (43-46)** - Complex data processing and reporting
- **Specialized Operations (47-50)** - Migration, recovery, and security
- **Maintenance (51-52)** - Performance tuning and system maintenance

---

## ?? Integration Examples

### Basic Service Registration
```csharp
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddMTMCoreServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Foundation Services (IMPLEMENTED)
        services.AddSingleton<IConfigurationService, ConfigurationService>();
        services.AddScoped<IDatabaseService, DatabaseService>();
        
        // Service Layer (TO BE IMPLEMENTED)
        services.AddScoped<IInventoryService, InventoryService>();
        services.AddScoped<IUserService, UserService>();
        
        // Infrastructure (TO BE IMPLEMENTED)
        services.AddSingleton<ICacheService, CacheService>();
        services.AddScoped<IValidationService, ValidationService>();
        services.AddScoped<IApplicationStateService, ApplicationStateService>();
        
        // Quality Assurance (TO BE IMPLEMENTED)
        services.AddSingleton<ILoggingService, LoggingService>();
        services.AddScoped<ISecurityService, SecurityService>();
        
        return services;
    }
}
```

### Error Handling Integration
```csharp
public class BaseService
{
    protected readonly ILogger _logger;

    protected async Task<Result<T>> ExecuteAsync<T>(Func<Task<T>> operation, string operationName)
    {
        try
        {
            _logger.LogInformation("Starting {OperationName}", operationName);
            var result = await operation();
            _logger.LogInformation("Completed {OperationName}", operationName);
            return Result<T>.Success(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed {OperationName}", operationName);
            Service_ErrorHandler.HandleException(ex, ErrorSeverity.High,
                source: operationName,
                additionalData: new Dictionary<string, object>
                {
                    ["OperationName"] = operationName,
                    ["Timestamp"] = DateTime.UtcNow
                });
            return Result<T>.Failure($"Operation {operationName} failed: {ex.Message}");
        }
    }
}
```

### Database Operations Pattern
```csharp
public class InventoryService : BaseService, IInventoryService
{
    private readonly IDatabaseService _databaseService;

    public InventoryService(IDatabaseService databaseService, ILogger<InventoryService> logger) : base(logger)
    {
        _databaseService = databaseService;
    }

    public async Task<Result<InventoryItem>> GetInventoryItemAsync(string partId)
    {
        return await ExecuteAsync(async () =>
        {
            // CRITICAL: Only stored procedures allowed
            var result = await _databaseService.ExecuteStoredProcedureAsync<InventoryItem>(
                "inv_inventory_Get_ByPartID",
                new Dictionary<string, object> { ["p_PartID"] = partId }
            );

            if (!result.IsSuccess)
                throw new InvalidOperationException($"Database error: {result.Error}");

            var item = result.Value.FirstOrDefault();
            if (item == null)
                throw new NotFoundException($"Inventory item {partId} not found");

            return item;
        }, $"GetInventoryItem_{partId}");
    }

    public async Task<Result<bool>> AddInventoryAsync(InventoryOperationRequest request)
    {
        return await ExecuteAsync(async () =>
        {
            // CRITICAL: TransactionType determined by USER INTENT, not Operation number
            var transactionType = request.UserAction switch
            {
                "ADD_STOCK" => TransactionType.IN,
                "REMOVE_STOCK" => TransactionType.OUT,
                "TRANSFER_STOCK" => TransactionType.TRANSFER,
                _ => throw new ArgumentException($"Invalid user action: {request.UserAction}")
            };

            var result = await _databaseService.ExecuteStoredProcedureWithStatusAsync<bool>(
                "inv_inventory_Add_Item",
                new Dictionary<string, object>
                {
                    ["p_PartID"] = request.PartID,
                    ["p_Location"] = request.Location,
                    ["p_Operation"] = request.Operation, // Just a workflow step number
                    ["p_Quantity"] = request.Quantity,
                    ["p_ItemType"] = request.ItemType,
                    ["p_User"] = request.User,
                    ["p_Notes"] = request.Notes,
                    ["p_TransactionType"] = transactionType.ToString() // Based on user intent
                }
            );

            if (!result.IsSuccess)
                throw new InvalidOperationException($"Database error: {result.Error}");

            return result.Value.IsSuccess;
        }, $"AddInventory_{request.PartID}");
    }
}
```

### Configuration Usage Pattern
```csharp
public class DatabaseService : IDatabaseService
{
    private readonly string _connectionString;
    private readonly int _commandTimeout;
    private readonly int _maxRetryAttempts;

    public DatabaseService(IConfigurationService configService, ILogger<DatabaseService> logger)
    {
        _connectionString = configService.GetConnectionString("DefaultConnection") 
            ?? throw new InvalidOperationException("DefaultConnection string not found in configuration");
        _commandTimeout = configService.GetValue<int>("Database:CommandTimeout", 30);
        _maxRetryAttempts = configService.GetValue<int>("Database:MaxRetryAttempts", 3);
    }
}
```

---

## ?? Notes

- **Status Legend**: ? Complete | ?? Missing | ?? Partial
- All prompts are designed to be framework-agnostic
- Each prompt builds upon previous implementations
- Prompts include comprehensive error handling and security considerations
- All implementations follow .NET 8 best practices and MTM business patterns
- Integration examples show real-world usage patterns for production applications
- Database operations enforce the critical "stored procedures only" security rule

---

**Last Updated:** 2025-01-27  
**Version:** 2.0.0  
**Compatibility:** .NET 8.0+  
**Total Prompts:** 52 (21-36 Core Systems + 37-52 Database Operations)