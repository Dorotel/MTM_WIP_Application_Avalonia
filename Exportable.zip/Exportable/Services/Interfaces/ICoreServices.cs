using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Threading;
using System.Threading.Tasks;
using MTM.Models; // TODO: Replace with actual Models namespace when implementing (e.g., YourProject.Models)

namespace MTM.Core.Services // TODO: Replace with actual Services namespace when implementing (e.g., YourProject.Services)
{
    /// <summary>
    /// Interface for configuration management service.
    /// Provides access to application settings and connection strings in a type-safe manner.
    /// </summary>
    public interface IConfigurationService
    {
        /// <summary>
        /// Gets a configuration value by key.
        /// </summary>
        string? GetValue(string key);
        
        /// <summary>
        /// Gets a strongly-typed configuration value by key.
        /// </summary>
        T? GetValue<T>(string key);
        
        /// <summary>
        /// Gets a strongly-typed configuration value with a default fallback.
        /// </summary>
        T GetValue<T>(string key, T defaultValue);
        
        /// <summary>
        /// Gets a connection string by name.
        /// </summary>
        string? GetConnectionString(string name);
        
        /// <summary>
        /// Gets a configuration section as a strongly-typed object.
        /// </summary>
        T? GetSection<T>(string sectionName) where T : class, new();
        
        /// <summary>
        /// Validates the current configuration for completeness and correctness.
        /// </summary>
        Result ValidateConfiguration();
        
        /// <summary>
        /// Reloads configuration from the source (useful for development scenarios).
        /// </summary>
        Task<Result> ReloadConfigurationAsync();
    }

    /// <summary>
    /// Interface for database service providing centralized data access.
    /// CRITICAL RULE: ALL database operations must use stored procedures - NO hard-coded SQL allowed.
    /// </summary>
    public interface IDatabaseService
    {
        /// <summary>
        /// Tests the database connection.
        /// </summary>
        Task<Result<bool>> TestConnectionAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes a stored procedure and returns the results.
        /// ENFORCES: Only stored procedures are allowed - NO direct SQL commands.
        /// </summary>
        Task<Result<List<T>>> ExecuteStoredProcedureAsync<T>(
            string procedureName, 
            Dictionary<string, object>? parameters = null, 
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes a stored procedure with status output parameters.
        /// Returns both the result set and status information from the procedure.
        /// </summary>
        Task<Result<StoredProcedureResult<T>>> ExecuteStoredProcedureWithStatusAsync<T>(
            string procedureName,
            Dictionary<string, object>? parameters = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes a stored procedure that returns a single scalar value.
        /// ENFORCES: Only stored procedures are allowed - NO direct SQL commands.
        /// </summary>
        Task<Result<T?>> ExecuteStoredProcedureScalarAsync<T>(
            string procedureName,
            Dictionary<string, object>? parameters = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes a stored procedure for non-query operations (INSERT, UPDATE, DELETE).
        /// Returns the number of affected rows.
        /// ENFORCES: Only stored procedures are allowed - NO direct SQL commands.
        /// </summary>
        Task<Result<int>> ExecuteStoredProcedureNonQueryAsync(
            string procedureName,
            Dictionary<string, object>? parameters = null,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes multiple stored procedures within a single transaction.
        /// Ensures data consistency across multiple database operations.
        /// </summary>
        Task<Result> ExecuteTransactionAsync(
            Func<IDbConnection, IDbTransaction, Task> operations,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// Executes multiple stored procedures within a single transaction and returns a result.
        /// </summary>
        Task<Result<T>> ExecuteTransactionAsync<T>(
            Func<IDbConnection, IDbTransaction, Task<T>> operations,
            CancellationToken cancellationToken = default);

        /// <summary>
        /// DEPRECATED: This method is provided for backward compatibility only.
        /// DO NOT USE: Direct query execution violates the "no hard-coded MySQL" rule.
        /// Use ExecuteStoredProcedureAsync instead.
        /// </summary>
        Task<Result<List<T>>> ExecuteQueryAsync<T>(string query, object? parameters = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// DEPRECATED: This method is provided for backward compatibility only.
        /// DO NOT USE: Direct command execution violates the "no hard-coded MySQL" rule.
        /// Use ExecuteStoredProcedureNonQueryAsync instead.
        /// </summary>
        Task<Result<int>> ExecuteNonQueryAsync(string command, object? parameters = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// DEPRECATED: This method is provided for backward compatibility only.
        /// DO NOT USE: Direct scalar query execution violates the "no hard-coded MySQL" rule.
        /// Use ExecuteStoredProcedureScalarAsync instead.
        /// </summary>
        Task<Result<T?>> ExecuteScalarAsync<T>(string query, object? parameters = null, CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Result container for stored procedures that return both data and status information.
    /// Used with ExecuteStoredProcedureWithStatusAsync to capture comprehensive procedure results.
    /// </summary>
    public class StoredProcedureResult<T>
    {
        public List<T> Data { get; set; } = new();
        public int Status { get; set; }
        public string? ErrorMessage { get; set; }
        public Dictionary<string, object> OutputParameters { get; set; } = new();
        
        public bool IsSuccess => Status == 0;
        public bool HasData => Data.Count > 0;
    }

    /// <summary>
    /// Interface for application state management service.
    /// Manages global application state including user context, connection status, and settings.
    /// </summary>
    public interface IApplicationStateService
    {
        /// <summary>
        /// Gets the currently logged in user.
        /// </summary>
        User? CurrentUser { get; }
        
        /// <summary>
        /// Gets whether a user is currently logged in.
        /// </summary>
        bool IsUserLoggedIn { get; }
        
        /// <summary>
        /// Gets the current database connection status.
        /// </summary>
        ConnectionStatus ConnectionStatus { get; }
        
        /// <summary>
        /// Gets all application settings.
        /// </summary>
        IReadOnlyDictionary<string, object> Settings { get; }

        /// <summary>
        /// Event fired when the current user changes.
        /// </summary>
        event EventHandler<UserChangedEventArgs>? CurrentUserChanged;
        
        /// <summary>
        /// Event fired when the connection status changes.
        /// </summary>
        event EventHandler<ConnectionStatusChangedEventArgs>? ConnectionStatusChanged;
        
        /// <summary>
        /// Event fired when a setting value changes.
        /// </summary>
        event EventHandler<SettingChangedEventArgs>? SettingChanged;

        /// <summary>
        /// Sets the current user context.
        /// </summary>
        void SetCurrentUser(User? user);
        
        /// <summary>
        /// Sets the connection status.
        /// </summary>
        void SetConnectionStatus(ConnectionStatus status);
        
        /// <summary>
        /// Gets a strongly-typed setting value.
        /// </summary>
        T? GetSetting<T>(string key);
        
        /// <summary>
        /// Sets a setting value.
        /// </summary>
        void SetSetting(string key, object value);
        
        /// <summary>
        /// Clears all state (useful for logout scenarios).
        /// </summary>
        void Clear();
    }

    /// <summary>
    /// Interface for caching service.
    /// Provides high-performance caching capabilities with support for various expiration strategies.
    /// </summary>
    public interface ICacheService
    {
        /// <summary>
        /// Gets a cached value by key.
        /// </summary>
        Task<T?> GetAsync<T>(string key, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Sets a value in the cache with optional expiration.
        /// </summary>
        Task<Result> SetAsync<T>(string key, T value, TimeSpan? expiration = null, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Removes a specific key from the cache.
        /// </summary>
        Task<Result> RemoveAsync(string key, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Removes all keys matching a pattern.
        /// </summary>
        Task<Result> RemoveByPatternAsync(string pattern, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Clears all cached items.
        /// </summary>
        Task<Result> ClearAllAsync(CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for validation service.
    /// Provides business rule validation using a flexible, extensible validation framework.
    /// </summary>
    public interface IValidationService
    {
        /// <summary>
        /// Validates an entity against all applicable business rules.
        /// </summary>
        Task<Result<ValidationResult>> ValidateAsync<T>(T entity, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Validates a specific business rule with context.
        /// </summary>
        Task<Result<bool>> ValidateRuleAsync(string ruleName, object context, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Gets all available validation rules for a type.
        /// </summary>
        Task<Result<List<string>>> GetValidationRulesAsync<T>(CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Registers a custom validation rule.
        /// </summary>
        Task<Result> RegisterValidationRuleAsync<T>(string ruleName, Func<T, ValidationResult> validator, CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for database connection factory.
    /// Provides abstraction for creating database connections with different providers.
    /// </summary>
    public interface IDbConnectionFactory
    {
        /// <summary>
        /// Creates and opens a new database connection.
        /// </summary>
        Task<DbConnection> CreateConnectionAsync();
        
        /// <summary>
        /// Gets the connection string used by this factory.
        /// </summary>
        string ConnectionString { get; }
    }

    /// <summary>
    /// Interface for user service.
    /// Provides user management and authentication functionality.
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        /// Gets a user by their ID.
        /// </summary>
        Task<Result<User?>> GetUserAsync(string userId, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Authenticates a user with their credentials.
        /// </summary>
        Task<Result<User?>> AuthenticateAsync(string username, string password, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Creates a new user.
        /// </summary>
        Task<Result<User>> CreateUserAsync(CreateUserRequest request, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Updates an existing user.
        /// </summary>
        Task<Result> UpdateUserAsync(UpdateUserRequest request, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Deletes a user.
        /// </summary>
        Task<Result> DeleteUserAsync(string userId, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Gets all users in the system.
        /// </summary>
        Task<Result<List<User>>> GetAllUsersAsync(CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for inventory service.
    /// Provides inventory management functionality following MTM business patterns.
    /// </summary>
    public interface IInventoryService
    {
        /// <summary>
        /// Gets an inventory item by Part ID.
        /// </summary>
        Task<Result<InventoryItem?>> GetInventoryItemAsync(string partId, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Searches for inventory items based on criteria.
        /// </summary>
        Task<Result<List<InventoryItem>>> SearchInventoryAsync(InventorySearchCriteria criteria, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Processes an inventory operation (add, remove, transfer).
        /// CRITICAL: TransactionType determined by user intent, NOT operation numbers.
        /// </summary>
        Task<Result<InventoryOperationResult>> ProcessInventoryOperationAsync(InventoryOperationRequest request, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Gets transaction history for a part.
        /// </summary>
        Task<Result<List<InventoryTransaction>>> GetTransactionHistoryAsync(string partId, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Gets quick transaction buttons for a user.
        /// </summary>
        Task<Result<List<QuickTransactionButton>>> GetQuickTransactionButtonsAsync(string userId, CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for security service.
    /// Provides authentication, authorization, and security-related functionality.
    /// </summary>
    public interface ISecurityService
    {
        /// <summary>
        /// Validates user permissions for a specific operation.
        /// </summary>
        Task<Result<bool>> ValidatePermissionAsync(string userId, string operation, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Gets user roles.
        /// </summary>
        Task<Result<List<Role>>> GetUserRolesAsync(string userId, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Logs a security event.
        /// </summary>
        Task<Result> LogSecurityEventAsync(SecurityEvent securityEvent, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Encrypts sensitive data.
        /// </summary>
        Task<Result<string>> EncryptAsync(string plainText, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Decrypts sensitive data.
        /// </summary>
        Task<Result<string>> DecryptAsync(string encryptedText, CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for logging service.
    /// Provides structured logging capabilities with various output targets.
    /// </summary>
    public interface ILoggingService
    {
        /// <summary>
        /// Logs an information message.
        /// </summary>
        Task LogInformationAsync(string message, Dictionary<string, object>? properties = null, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Logs a warning message.
        /// </summary>
        Task LogWarningAsync(string message, Dictionary<string, object>? properties = null, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Logs an error message.
        /// </summary>
        Task LogErrorAsync(string message, Exception? exception = null, Dictionary<string, object>? properties = null, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Logs a critical error message.
        /// </summary>
        Task LogCriticalAsync(string message, Exception? exception = null, Dictionary<string, object>? properties = null, CancellationToken cancellationToken = default);
        
        /// <summary>
        /// Logs a debug message.
        /// </summary>
        Task LogDebugAsync(string message, Dictionary<string, object>? properties = null, CancellationToken cancellationToken = default);
    }

    #region Event Argument Classes

    /// <summary>
    /// Event arguments for user change events.
    /// </summary>
    public class UserChangedEventArgs : EventArgs
    {
        public User? PreviousUser { get; }
        public User? CurrentUser { get; }

        public UserChangedEventArgs(User? previousUser, User? currentUser)
        {
            PreviousUser = previousUser;
            CurrentUser = currentUser;
        }
    }

    /// <summary>
    /// Event arguments for connection status change events.
    /// </summary>
    public class ConnectionStatusChangedEventArgs : EventArgs
    {
        public ConnectionStatus PreviousStatus { get; }
        public ConnectionStatus CurrentStatus { get; }

        public ConnectionStatusChangedEventArgs(ConnectionStatus previousStatus, ConnectionStatus currentStatus)
        {
            PreviousStatus = previousStatus;
            CurrentStatus = currentStatus;
        }
    }

    /// <summary>
    /// Event arguments for setting change events.
    /// </summary>
    public class SettingChangedEventArgs : EventArgs
    {
        public string Key { get; }
        public object? PreviousValue { get; }
        public object CurrentValue { get; }

        public SettingChangedEventArgs(string key, object? previousValue, object currentValue)
        {
            Key = key;
            PreviousValue = previousValue;
            CurrentValue = currentValue;
        }
    }

    #endregion

    #region Request/Response Models

    /// <summary>
    /// Request model for creating a new user.
    /// </summary>
    public class CreateUserRequest
    {
        public string UserName { get; set; } = string.Empty;
        public string? FullName { get; set; }
        public string Shift { get; set; } = "1";
        public bool VitsUser { get; set; }
        public string? Pin { get; set; }
        public string Theme_Name { get; set; } = "Default (Black and White)";
        public int Theme_FontSize { get; set; } = 9;
    }

    /// <summary>
    /// Request model for updating an existing user.
    /// </summary>
    public class UpdateUserRequest
    {
        public string UserId { get; set; } = string.Empty;
        public string? FullName { get; set; }
        public string? Shift { get; set; }
        public bool? VitsUser { get; set; }
        public string? Pin { get; set; }
        public string? Theme_Name { get; set; }
        public int? Theme_FontSize { get; set; }
    }

    /// <summary>
    /// Security event model for audit logging.
    /// </summary>
    public class SecurityEvent
    {
        public string EventType { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public Dictionary<string, object> Properties { get; set; } = new();
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }

    #endregion
}