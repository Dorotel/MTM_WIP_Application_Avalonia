using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MTM.Models; // TODO: Replace with actual Models namespace when implementing (e.g., YourProject.Models)

namespace MTM.Services // TODO: Replace with actual Services namespace when implementing (e.g., YourProject.Services)
{
    /// <summary>
    /// Interface for inventory management operations following MTM business patterns.
    /// CRITICAL: TransactionType is determined by USER INTENT, not Operation numbers.
    /// </summary>
    public interface IInventoryService
    {
        /// <summary>
        /// Gets all inventory items asynchronously.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing list of inventory items</returns>
        Task<Result<List<InventoryItem>>> GetInventoryAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets a specific inventory item by Part ID.
        /// </summary>
        /// <param name="partId">The part ID to search for</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing the inventory item if found</returns>
        Task<Result<InventoryItem?>> GetInventoryItemAsync(string partId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Adds a new inventory item.
        /// </summary>
        /// <param name="item">The inventory item to add</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> AddInventoryItemAsync(InventoryItem item, CancellationToken cancellationToken = default);

        /// <summary>
        /// Updates an existing inventory item.
        /// </summary>
        /// <param name="item">The inventory item to update</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> UpdateInventoryItemAsync(InventoryItem item, CancellationToken cancellationToken = default);

        /// <summary>
        /// Processes an MTM operation (e.g., "90", "100", "110") for a specific part.
        /// IMPORTANT: Operation numbers are workflow steps, NOT transaction type indicators.
        /// TransactionType should be determined by the user's intent (adding, removing, transferring stock).
        /// </summary>
        /// <param name="partId">The part ID</param>
        /// <param name="operation">The operation number as string (workflow step identifier)</param>
        /// <param name="quantity">The quantity to process</param>
        /// <param name="location">The location for the operation</param>
        /// <param name="userId">The user performing the operation</param>
        /// <param name="transactionType">The type of transaction based on user intent</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> ProcessOperationAsync(string partId, string operation, int quantity, string location, string userId, TransactionType transactionType, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets inventory items by location.
        /// </summary>
        /// <param name="location">The location to filter by</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing filtered inventory items</returns>
        Task<Result<List<InventoryItem>>> GetInventoryByLocationAsync(string location, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets inventory items by operation.
        /// </summary>
        /// <param name="operation">The operation to filter by</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing filtered inventory items</returns>
        Task<Result<List<InventoryItem>>> GetInventoryByOperationAsync(string operation, CancellationToken cancellationToken = default);

        /// <summary>
        /// Searches inventory items based on search criteria.
        /// </summary>
        /// <param name="criteria">Search criteria</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing matching inventory items</returns>
        Task<Result<List<InventoryItem>>> SearchInventoryAsync(InventorySearchCriteria criteria, CancellationToken cancellationToken = default);

        /// <summary>
        /// Processes an inventory operation with full context.
        /// CRITICAL: TransactionType must be determined by user intent, NOT operation number.
        /// </summary>
        /// <param name="request">Complete inventory operation request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing operation details</returns>
        Task<Result<InventoryOperationResult>> ProcessInventoryOperationAsync(InventoryOperationRequest request, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets transaction history for a part.
        /// </summary>
        /// <param name="partId">The part ID</param>
        /// <param name="fromDate">Optional start date filter</param>
        /// <param name="toDate">Optional end date filter</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing transaction history</returns>
        Task<Result<List<InventoryTransaction>>> GetTransactionHistoryAsync(string partId, DateTime? fromDate = null, DateTime? toDate = null, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets quick transaction buttons for a user.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing quick transaction buttons</returns>
        Task<Result<List<QuickTransactionButton>>> GetQuickTransactionButtonsAsync(string userId, CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for user management operations.
    /// </summary>
    public interface IUserService
    {
        /// <summary>
        /// Gets the current authenticated user.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing the current user</returns>
        Task<Result<User?>> GetCurrentUserAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Authenticates a user with username and password.
        /// </summary>
        /// <param name="username">The username</param>
        /// <param name="password">The password</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing authenticated user</returns>
        Task<Result<User>> AuthenticateAsync(string username, string password, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets all active users.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing list of active users</returns>
        Task<Result<List<User>>> GetActiveUsersAsync(CancellationToken cancellationToken = default);

        /// <summary>
        /// Updates user's last login timestamp.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> UpdateLastLoginAsync(string userId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets a user by their ID.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing the user if found</returns>
        Task<Result<User?>> GetUserAsync(string userId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Creates a new user.
        /// </summary>
        /// <param name="request">User creation request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing the created user</returns>
        Task<Result<User>> CreateUserAsync(CreateUserRequest request, CancellationToken cancellationToken = default);

        /// <summary>
        /// Updates an existing user.
        /// </summary>
        /// <param name="request">User update request</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> UpdateUserAsync(UpdateUserRequest request, CancellationToken cancellationToken = default);

        /// <summary>
        /// Deletes a user.
        /// </summary>
        /// <param name="userId">The user ID to delete</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> DeleteUserAsync(string userId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets all users in the system.
        /// </summary>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing all users</returns>
        Task<Result<List<User>>> GetAllUsersAsync(CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for transaction management operations.
    /// </summary>
    public interface ITransactionService
    {
        /// <summary>
        /// Gets transaction history for a specific part.
        /// </summary>
        /// <param name="partId">The part ID</param>
        /// <param name="limit">Maximum number of transactions to return</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing transaction history</returns>
        Task<Result<List<InventoryTransaction>>> GetTransactionHistoryAsync(string partId, int limit = 50, CancellationToken cancellationToken = default);

        /// <summary>
        /// Logs a new inventory transaction.
        /// CRITICAL: Ensure TransactionType is set based on user intent, not operation number.
        /// </summary>
        /// <param name="transaction">The transaction to log</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> LogTransactionAsync(InventoryTransaction transaction, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets the last N transactions for a user.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="limit">Maximum number of transactions to return</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing user's recent transactions</returns>
        Task<Result<List<InventoryTransaction>>> GetUserTransactionsAsync(string userId, int limit = 10, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets all transactions within a date range.
        /// </summary>
        /// <param name="startDate">Start date for the range</param>
        /// <param name="endDate">End date for the range</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing transactions in the date range</returns>
        Task<Result<List<InventoryTransaction>>> GetTransactionsByDateRangeAsync(DateTime startDate, DateTime endDate, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets transactions by transaction type.
        /// </summary>
        /// <param name="transactionType">The transaction type to filter by</param>
        /// <param name="limit">Maximum number of transactions to return</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing filtered transactions</returns>
        Task<Result<List<InventoryTransaction>>> GetTransactionsByTypeAsync(TransactionType transactionType, int limit = 50, CancellationToken cancellationToken = default);

        /// <summary>
        /// Gets transactions by operation number.
        /// Note: Operation is a workflow step identifier, not a transaction type indicator.
        /// </summary>
        /// <param name="operation">The operation number to filter by</param>
        /// <param name="limit">Maximum number of transactions to return</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing filtered transactions</returns>
        Task<Result<List<InventoryTransaction>>> GetTransactionsByOperationAsync(string operation, int limit = 50, CancellationToken cancellationToken = default);
    }

    /// <summary>
    /// Interface for quick button management operations.
    /// </summary>
    public interface IQuickButtonService
    {
        /// <summary>
        /// Gets quick buttons for a specific user.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result containing user's quick buttons</returns>
        Task<Result<List<QuickButtonItem>>> GetUserQuickButtonsAsync(string userId, CancellationToken cancellationToken = default);

        /// <summary>
        /// Updates a quick button.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="position">The button position (1-10)</param>
        /// <param name="quickButton">The updated quick button data</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> UpdateQuickButtonAsync(string userId, int position, QuickButtonItem quickButton, CancellationToken cancellationToken = default);

        /// <summary>
        /// Removes a quick button.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="position">The button position to remove</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> RemoveQuickButtonAsync(string userId, int position, CancellationToken cancellationToken = default);

        /// <summary>
        /// Records usage of a quick button for analytics.
        /// </summary>
        /// <param name="userId">The user ID</param>
        /// <param name="position">The button position used</param>
        /// <param name="cancellationToken">Cancellation token</param>
        /// <returns>Result indicating success or failure</returns>
        Task<Result> RecordQuickButtonUsageAsync(string userId, int position, CancellationToken cancellationToken = default);
    }

    #region Supporting Models for Business Services

    /// <summary>
    /// Search criteria for inventory operations.
    /// </summary>
    public class InventorySearchCriteria
    {
        public string? PartId { get; set; }
        public string? Location { get; set; }
        public string? Operation { get; set; }
        public int? MinQuantity { get; set; }
        public int? MaxQuantity { get; set; }
        public DateTime? LastUpdatedAfter { get; set; }
        public DateTime? LastUpdatedBefore { get; set; }
        public bool? IsActive { get; set; }
    }

    /// <summary>
    /// Request model for inventory operations.
    /// CRITICAL: TransactionType must be determined by user intent, not operation number.
    /// </summary>
    public class InventoryOperationRequest
    {
        public string PartId { get; set; } = string.Empty;
        public string Operation { get; set; } = string.Empty; // Workflow step number
        public int Quantity { get; set; }
        public string Location { get; set; } = string.Empty;
        public string? ToLocation { get; set; } // For transfer operations
        public string UserId { get; set; } = string.Empty;
        public TransactionType TransactionType { get; set; } // Based on user intent
        public string? Notes { get; set; }
        public Dictionary<string, object> AdditionalData { get; set; } = new();
    }

    /// <summary>
    /// Result model for inventory operations.
    /// </summary>
    public class InventoryOperationResult
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
        public string? TransactionId { get; set; }
        public InventoryItem? UpdatedItem { get; set; }
        public int NewQuantity { get; set; }
        public DateTime ProcessedAt { get; set; }
        public Dictionary<string, object> AdditionalData { get; set; } = new();
    }

    /// <summary>
    /// Model for quick transaction buttons.
    /// </summary>
    public class QuickTransactionButton
    {
        public int Position { get; set; }
        public string PartId { get; set; } = string.Empty;
        public string Operation { get; set; } = string.Empty; // Workflow step number
        public int Quantity { get; set; }
        public string DisplayText { get; set; } = string.Empty;
        public TransactionType TransactionType { get; set; } // User's intended transaction type
        public DateTime LastUsed { get; set; }
        public int UsageCount { get; set; }
        public bool IsActive { get; set; } = true;
    }

    #endregion
}